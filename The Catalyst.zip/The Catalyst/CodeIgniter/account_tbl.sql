-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 11, 2021 at 07:17 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `management`
--

-- --------------------------------------------------------

--
-- Table structure for table `account_tbl`
--

CREATE TABLE `account_tbl` (
  `account_id` int(11) NOT NULL,
  `account_fname` varchar(200) NOT NULL,
  `account_lname` varchar(200) NOT NULL,
  `account_uname` varchar(200) NOT NULL,
  `account_password` varchar(200) NOT NULL,
  `account_avatar` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `account_tbl`
--

INSERT INTO `account_tbl` (`account_id`, `account_fname`, `account_lname`, `account_uname`, `account_password`, `account_avatar`) VALUES
(1, 'Liezyl', 'Tolentino', 'lie09tolentino', 'NEW099804', 'avatar1.png'),
(2, 'Lorna', 'Tolentino', 'lorna029323234', 'lorna029323234', 'avatar1.png'),
(3, 'Cris', 'Tolentino', 'Cris122973', 'pwd12345', 'avatar1.png'),
(4, 'Liezyl', 'Tolenitno', 'newUname12', 'newUname12', 'avatar1.png'),
(5, 'Mae', 'Tolen', 'mae02325434', 'mae02325434', 'avatar1.png'),
(6, 'ako', 'langto', 'ako23232', 'pafddfdf', 'avatar1.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account_tbl`
--
ALTER TABLE `account_tbl`
  ADD PRIMARY KEY (`account_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account_tbl`
--
ALTER TABLE `account_tbl`
  MODIFY `account_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
