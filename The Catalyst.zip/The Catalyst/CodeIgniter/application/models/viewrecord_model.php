<?php
    class Viewrecord_model extends CI_Model {
        public function get_record(){
            //SELECT
            $res = $_GET['acctId'];

            $this->db->where('account_id', $res);
            $this->db->from('account_tbl');
            $query = $this->db->get(); 

            $result = $query->result();
            return $result; 
        }
        public function get_vax_record(){
            $res = $_GET['acctId'];

            $this->db->where('vaccination_resid', $res);
            $this->db->from('vaccination_tbl');
            $query = $this->db->get(); 
            $result = $query->result();
            return $result; 
        }
        public function get_stat(){
            $query = $this->db->get('vaccinationstas_tbl');
            $result = $query->result();
            return $result;
        }

        public function get_res_record(){
            //SELECT
            $res = '1';

            $this->db->where('account_id', $res);
            $this->db->from('account_tbl');
            $query = $this->db->get(); 

            $result = $query->result();
            return $result; 
        }
        public function get_res_vax_record(){
            $res = '1';

            $this->db->where('vaccination_resid', $res);
            $this->db->from('vaccination_tbl');
            $query = $this->db->get(); 
            $result = $query->result();
            return $result; 
        }
    }