<?php
    class Vaccination_Model extends CI_Model{
        
        public function checkUniqueUsername($data){

            $query=$this->db->get_where('account_tbl',array('account_uname'=>$data));
            if($query->num_rows()>0){
                return $query->result();
            }
            else{
                return FALSE;
            }  
        }
        
        public function checkExistingAccount($uname,$pass){
            $array=array('account_uname'=>$uname, 'account_password'=>$pass);
            $query=$this->db->get_where('account_tbl',$array);
            if($query->num_rows()>0){
                return 'resident';
            }
            else{
                $array1=array('admin_uname'=>$uname, 'admin_password'=>$pass);
                $query1=$this->db->get_where('admin_tbl',$array1);
                if($query1->num_rows()>0){
                    return 'admin';
                }
                else{
                    return FALSE;
                }
                
            }
        }


        public function getFirstName($tbl,$tblname,$col1,$uname,$col2,$pass){
            $col=$tbl.'_fname';
            $this->db->select($col);
            $query=$this->db->get_where($tblname, array($col1=>$uname, $col2=>$pass));
            return $query->result();
        }
        

        public function getAccountDetails($tblname,$col1,$uname,$col2,$pass){
            $query=$this->db->get_where($tblname, array($col1=>$uname, $col2=>$pass));
            return $query->result();
        }
        public function checkPassMatch($table,$accountId,$currPass){

            $query=$this->db->get_where($table,array('account_id'=>$accountId,'account_password'=>$currPass));
            if($query->num_rows()>0){
                return TRUE;
            }
            else{
                return FALSE;
            }
        }

        public function updatePassword($accountId,$newPassword){
            $data=array(
                'account_password'=>$newPassword
            );
            $this->db->where('account_id',$accountId);
            $this->db->update('account_tbl',$data);
            return TRUE;
        }

        public function getPriorityCategory($table){
            $this->db->order_by('priority_id','ASC');
            $query = $this->db->get($table);
            $result = $query->result();
            return $result;
        }
        public function imageUpload($imgArray){
            $this->db->where();
            $result=$this->db->update('account_tbl',$imgArray);
            if($result){
                return TRUE;
            }
            else{
                return FALSE;
            }
        }
        
        public function getUserDetails_limited($limit,$offset){
            $this->db->limit($limit,$offset);
            $query = $this->db->get('account_tbl');
            $result = $query->result();
            return $result;
        }

        public function getUserAccounts(){
            $query=$this->db->get('account_tbl');
            $result=$query->result();
            return $result;
        }
        public function getAdminAccounts(){
            $query=$this->db->get('admin_tbl');
            $result=$query->result();
            return $result;
        }

        public function getAccountDetailsById($tblname,$id_column,$id){
            $query=$this->db->get_where($tblname,array($id_column=>$id));
            return $query->result();  

        }
        public function getApprovalStatus(){
            $query=$this->db->get('approvalstat_tbl');
            $result=$query->result();
            return $result;
        }

        public function getAccountStatus(){
            $query=$this->db->get('accstatus_tbl');
            $result=$query->result();
            return $result;
        }
    }
