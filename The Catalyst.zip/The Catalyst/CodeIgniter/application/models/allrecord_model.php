<?php
    class Allrecord_model extends CI_Model {
        public function get_record(){
            $stat = '1';

            $this->db->where('account_approvalStat', $stat);
            $this->db->from('account_tbl');
            $query = $this->db->get(); 
            $result = $query->result();
            return $result; 

            $result = $query->result();
            return $result;
        }
    }