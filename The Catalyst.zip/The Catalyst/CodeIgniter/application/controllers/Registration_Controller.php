<?php
    class Registration_Controller extends CI_Controller {

        public function __construct(){
            parent::__construct();
            $this->load->helper('url');
            $this->load->helper('form');
            $this->load->database('vaccination');
            $this->load->model('Vaccination_Model','vaccModel');
            $this->load->library('session');
            $this->load->library('email');

            if(!$this->session->userdata('is_logged'))
            {
                redirect('Login_Controller');
            }
        }

        public function loadSample(){
            $this->load->helper('url');
            // $this->load->view('Admin_User_Management');
            $this->load->view('Resident_Profile');
        }

        function index()
        {
            $this->load->view('Login_View');
        }

        public function registerAccount()
        {
            $this->load->helper(array('form', 'url'));
            $this->load->library('form_validation');
            $this->load->library('upload');


            $this->form_validation->set_rules('fname', 'First Name', 'required|alpha');
            $this->form_validation->set_rules('mname', 'Middle Name', 'required|alpha');
            $this->form_validation->set_rules('lname', 'Last Name', 'required|alpha');
            $this->form_validation->set_rules('username', 'Username', 'required|alpha_numeric|min_length[8]|is_unique[account_tbl.account_uname]');
            $this->form_validation->set_rules('password', 'Password', 'required|min_length[8]');
            $this->form_validation->set_rules('passconf', 'Confirm Password','required|min_length[8]|matches[password]');
            $this->form_validation->set_rules('birthdate', 'Birthdate','required');
            $this->form_validation->set_rules('gender', 'Gender','required|alpha');
            $this->form_validation->set_rules('housenum', 'House Number','required');
            $this->form_validation->set_rules('street', 'Street','required');
            $this->form_validation->set_rules('subdivision', 'Subdivision','required');
            $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
            $this->form_validation->set_rules('contact', 'Contact Number', 'required|numeric|min_length[11]|max_length[11]');
            $this->form_validation->set_rules('priorityCateg', 'Priority Category', 'required');
            $this->form_validation->set_rules('others', 'Others', 'alpha');
                
            $data=array(
                'category' => $this->vaccModel->getPriorityCategory('priority_tbl'),
                // 'errors'=>$error
            ); 
            if ($this->form_validation->run() == FALSE){
                $this->load->view('Registration_View',$data);
                return FALSE;
            }
            else{
                $config=array(
                    'upload_path'=>'./upload/',
                    'allowed_types'=>'jpg|jpeg|png|JPEG|JPG|PNG'
                );
                $this->upload->initialize($config);
                $this->upload->do_upload('validid');
                $validID=$this->upload->data('file_name');

                $config=array(
                    'upload_path'=>'./upload/',
                    'allowed_types'=>'jpg|jpeg|png|JPEG|JPG|PNG'
                );
                $this->upload->initialize($config);
                $this->upload->do_upload('profile_pic');
                $profilePic=$this->upload->data('file_name');


                $config=array(
                    'upload_path'=>'./upload/',
                    'allowed_types'=>'jpg|jpeg|png|JPEG|JPG|PNG'
                );
                $this->upload->initialize($config);
                $this->upload->do_upload('proof');
                $residency=$this->upload->data('file_name');

                $config=array(
                    'upload_path'=>'./upload/',
                    'allowed_types'=>'jpg|jpeg|png|JPEG|JPG|PNG'
                );
                $this->upload->initialize($config);
                $this->upload->do_upload('coe');
                $coe=$this->upload->data('file_name');

                $config=array(
                    'upload_path'=>'./upload/',
                    'allowed_types'=>'jpg|jpeg|png|JPEG|JPG|PNG'
                );
                $this->upload->initialize($config);
                $this->upload->do_upload('senior');
                $senior=$this->upload->data('file_name');

                $config=array(
                    'upload_path'=>'./upload/',
                    'allowed_types'=>'jpg|jpeg|png|JPEG|JPG|PNG'
                );
                $this->upload->initialize($config);
                $this->upload->do_upload('medcert');
                $medcert=$this->upload->data('file_name');

                $config=array(
                    'upload_path'=>'./upload/',
                    'allowed_types'=>'jpg|jpeg|png|JPEG|JPG|PNG'
                );
                $this->upload->initialize($config);
                $this->upload->do_upload('prescrip');
                $prescrip=$this->upload->data('file_name');

                
                $config=array(
                    'upload_path'=>'./upload/',
                    'allowed_types'=>'jpg|jpeg|png|JPEG|JPG|PNG'
                );
                $this->upload->initialize($config);
                $this->upload->do_upload('coi');
                $coi=$this->upload->data('file_name');

                $config=array(
                    'upload_path'=>'./upload/',
                    'allowed_types'=>'jpg|jpeg|png|JPEG|JPG|PNG'
                );
                $this->upload->initialize($config);
                $this->upload->do_upload('otherAttach');
                $otherAttach=$this->upload->data('file_name');


                    $basicInfo=array(
                        'account_fname'=>$_POST['fname'],
                        'account_mname'=>$_POST['mname'],
                        'account_lname'=>$_POST['lname'],
                        'account_uname'=>$_POST['username'],
                        'account_password'=>$_POST['password'],
                        'account_bdate'=>$_POST['birthdate'],
                        'account_gender'=>$_POST['gender'],
                        'account_housenum'=>$_POST['housenum'],
                        'account_street'=>$_POST['street'],
                        'account_subdivision'=>$_POST['subdivision'],
                        'account_email'=>$_POST['email'],
                        'account_contactnum'=>$_POST['contact'],
                        'account_prioritycateg'=>$_POST['priorityCateg'],
                        'account_image'=>$profilePic,
                        'account_validid'=>$validID,
                        'account_residency'=>$residency,
                        'account_registerdate'=>date('Y-m-d H:i:s'),
                        'account_approvalStat'=>3,
                        'account_status'=>1,
                        'account_allergy'=>$_POST['radioAllergy'],
                        'account_disease'=>$_POST['radioDiseases'],
                        'account_diabetic'=>$_POST['radioDiabetic'],
                        'account_hypertension'=>$_POST['radioHypertension'],
                        'account_transplant'=>$_POST['radioOrgan'],
                        'account_fever'=>$_POST['radioFever'],
                        'account_cough'=>$_POST['radioCough'],
                        'account_bodypain'=>$_POST['radioBodyPain'],
                        'account_breath'=>$_POST['radioBreath'],
                        'account_smell'=>$_POST['radioTaste'],
                        'account_diarrhea'=>$_POST['radioDiarrhea'],
                        'account_others'=>$_POST['others'],
                        'account_senior'=>$senior,
                        'account_coe'=>$coe,
                        'account_medcert'=>$medcert,
                        'account_medreceipt'=>$prescrip,
                        'account_indigency'=>$coi,
                        'account_otherAttach'=>$otherAttach,
                    );
                    $config=array(
                        'protocol' => 'smtp',
                        'smtp_host' => 'ssl://smtp.gmail.com',
                        'smtp_port'=> '465',
                        'smtp_user'=> 'iturok571@gmail.com',
                        'smtp_pass'=> 'catalyst123',
                        'charset' => 'iso-8859-1',
                        'mailtype'=> 'html',
                        'wordwrap'=>TRUE,
                        'newline'=> "\r\n",
                    );
                    $email=$_POST['email'];
                    $this->load->library('email',$config);
                    $this->email->from('iturok571@gmail.com', 'Barangay San Antonio');
                    $this->email->to($email); //Palitan ng account email galing database
                    $this->email->subject('Account Verification');
                    $this->email->message('Your request has been approved. Please click the link to redirect you to login');
                    $this->email->set_newline("\r\n");

                    if($this->email->send()){
                        $this->db->insert('account_tbl',$basicInfo);
                        $this->load->view('resident/EmailSent');
                    }
                    else{
                        // show_error($this->email->print_debugger());
                        $this->load->view('resident/EmailFailed');
                    }
            }
        }

        public function profileAccount(){
            $accountId=$this->input->post('account_id', true);
            $this->load->helper(array('form', 'url'));
            $this->load->library('form_validation');
            $this->form_validation->set_rules('currpassword', 'Enter Current Password', 'required|min_length[8]|callback_matchCurrentPass');
            $this->form_validation->set_rules('newpassword', '', 'required|min_length[8]');
            $this->form_validation->set_rules('newpassconf', '', 'required|min_length[8]|matches[newpassword]',['matches'=>'New password and Re- Enter new password should be the same.']);
            
            $button=$this->input->post('submitForm');
            if($button=='Reset Password'){
                if ($this->form_validation->run() == FALSE){
                    $data=array(
                        'content'=>$this->vaccModel->getAccountById('account_tbl',$accountId)
                    );
                    
                    $this->load->view('Profile_View',$data);
                    return FALSE;
                }
                else{
                    $accountId=$this->input->post('account_id', true);
                    $newPassword=$this->input->post('newpassword',true);
                    $this->vaccModel->updatePassword($accountId,$newPassword);
                    $data=array(
                        'content'=>$this->vaccModel->getAccountById('account_tbl',$accountId)
                    );
                    
                    $this->form_validation->set_message('matchCurrentPass','updted');
                    $this->load->view('profile_View',$data);
                    return TRUE;
                }  
            }
            else{
                $this->load->view('Login_View');
            }
    
        }

        public function matchCurrentPass($newPass){
            $accountId=$this->input->post('account_id', true);

            $data=array(
                'content'=>$this->vaccModel->getAccountById('account_tbl',$accountId)
            );
        
            if($this->vaccModel->checkPassMatch('account_tbl',$accountId,$newPass)){
                return TRUE;
            }
            else{
                 
                $this->form_validation->set_message('matchCurrentPass','Current password is not the same with the old password');
                return FALSE;
            }
        }
    }