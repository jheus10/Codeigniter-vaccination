<?php
    class Login_Controller extends CI_Controller {

        public function __construct(){
            parent::__construct();
            $this->load->helper('url');
            $this->load->helper('form');
            $this->load->database('vaccination');
            $this->load->model('Vaccination_Model','vaccModel');

        }

        public function index(){
            $this->load->helper(array('form', 'url'));
            $this->load->library('form_validation');

            $this->form_validation->set_rules('username', 'Username', 'required|alpha_numeric|min_length[8]');
            $this->form_validation->set_rules('password', 'Password', 'required|callback_existingAccount');

            
            if ($this->form_validation->run() == FALSE){
                $this->load->view('Login_View');
                return FALSE;
            }
            else{
                $uname=$_POST['username'];
                $pass=$_POST['password'];
            
                // $this->load->view('Profile_View',$data);
                if(($this->vaccModel->checkExistingAccount($uname,$pass))=='resident'){
                    $data=array(
                        'content'=> $this->vaccModel->getAccountDetails('account_tbl','account_uname',$uname,'account_password',$pass),
                        'alluser'=> $this->vaccModel->getUserAccounts(),
                        'alladmin'=> $this->vaccModel->getAdminAccounts(),
                        // 'content'=> $this->vaccModel->getAccountDetails('account_tbl','account_uname',$uname,'account_password',$pass)
                    );
                    $firstname=$this->vaccModel->getFirstName('account','account_tbl','account_uname',$uname,'account_password',$pass);
                    foreach($firstname as $info){
                        $fname=$info->account_fname;
                    }
                    $this->session->is_logged=true;
                    $this->session->username=$uname;
                    $this->session->password=$pass;
                    $this->session->fname=$fname;
                    $this->session->accounttype='resident';
                    $this->load->view('resident/Dashboard',$data);
                }
                elseif(($this->vaccModel->checkExistingAccount($uname,$pass))=='admin'){
                    $data=array(
                        'content'=> $this->vaccModel->getAccountDetails('admin_tbl','admin_uname',$uname,'admin_password',$pass)
                    );
                    $firstname=$this->vaccModel->getFirstName('admin','admin_tbl','admin_uname',$uname,'admin_password',$pass);
                    foreach($firstname as $info){
                        $fname=$info->admin_fname;
                    }
                    $this->session->is_logged=true;
                    $this->session->username=$uname;
                    $this->session->password=$pass;
                    $this->session->fname=$fname;
                    $this->session->accounttype='admin';
                    $this->load->view('admin/Dashboard',$data);
                }
                else{
                   return FALSE;
                }
            }
        }
            
        public function existingAccount(){
        $uname=$this->input->post('username', true);
        $pass=$this->input->post('password', true);

            if(($this->vaccModel->checkExistingAccount($uname,$pass))=='resident'){
                $data=array(
                    'content'=> $this->vaccModel->getAccountDetails('account_tbl','account_uname',$uname,'account_password',$pass),
                    'alluser'=> $this->vaccModel->getUserAccounts(),
                    'alladmin'=> $this->vaccModel->getAdminAccounts(),
                    
                );
                $this->load->view('resident/Dashboard',$data);
                // $this->load->view('dashboard-resident',$data);
                return TRUE;
            }
            elseif(($this->vaccModel->checkExistingAccount($uname,$pass))=='admin'){
                $data=array(
                    'content'=> $this->vaccModel->getAccountDetails('admin_tbl','admin_uname',$uname,'admin_password',$pass)
                );
                $this->load->view('admin/Dashboard',$data);
                // $this->load->view('dashboard-admin',$data);
                return TRUE;
            }
            else{
                $this->form_validation->set_message('existingAccount','Invalid username or password');
                return FALSE;
            }
        }

        public function logout(){
            $this->session->sess_destroy();
            redirect('Login_Controller');
        }

        public function DisplayAccount(){
            $this->load->helper('url');
            $uname= $this->session->username;
            $pass= $this->session->password;
            $data=array(
                'content'=> $this->vaccModel->getAccountDetails('account_tbl','account_uname',$uname,'account_password',$pass),
                'alluser'=> $this->vaccModel->getUserAccounts(),
                'alladmin'=> $this->vaccModel->getAdminAccounts(),
            );
            
            $this->load->view('admin/Dashboard',$data);
        }

        public function UserManagement(){
            $this->load->helper('url');
            $uname= $this->session->username;
            $pass= $this->session->password;
            $data=array(
                'content'=> $this->vaccModel->getAccountDetails('account_tbl','account_uname',$uname,'account_password',$pass),
                'alluser'=> $this->vaccModel->getUserAccounts(),
                'alladmin'=> $this->vaccModel->getAdminAccounts(),
            );
            $this->load->view('admin/User_Management',$data);
        }


        public function viewAdmin(){
            $uname= $this->session->username;
            $pass= $this->session->password;
            $data=array(
                
                'content'=> $this->vaccModel->getAccountDetails('account_tbl','account_uname',$uname,'account_password',$pass),
                'userId'=>$this->vaccModel->getAccountDetailsById('admin_tbl','admin_id',$this->uri->segment(3))
            );
            // print_r($data);
            $this->load->view('admin/viewAdminAccount',$data);
        }
        public function viewAdminProfile(){
           $this->load->view('admin/Profile');
        }

        public function createAdminAccount(){
            $this->load->helper(array('form', 'url'));
            $this->load->library('form_validation');
            $this->load->library('upload');


            $this->form_validation->set_rules('fname', 'First Name', 'required|alpha');
            $this->form_validation->set_rules('mname', 'Middle Name', 'required|alpha');
            $this->form_validation->set_rules('lname', 'Last Name', 'required|alpha');
            $this->form_validation->set_rules('username', 'Username', 'required|alpha_numeric|min_length[8]|is_unique[admin_tbl.admin_uname]');
            $this->form_validation->set_rules('password', 'Password', 'required|min_length[8]');
            $this->form_validation->set_rules('passconf', 'Confirm Password','required|min_length[8]|matches[password]');
            $this->form_validation->set_rules('bdate', 'Birthdate','required');
            $this->form_validation->set_rules('gender', 'Gender','required|alpha');
            $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
            $this->form_validation->set_rules('housenum', 'House Number','required');
            $this->form_validation->set_rules('street', 'Street','required');
            $this->form_validation->set_rules('subdivision', 'Subdivision','required');
            $this->form_validation->set_rules('contact', 'Contact Number', 'required|numeric|min_length[11]|max_length[11]');
            $this->form_validation->set_rules('status', 'Status', 'required');

            if ($this->form_validation->run() == FALSE){
                $data = array(
                    'code' => 1,
                    'msg' => validation_errors(),
                );
                echo json_encode($data);
            }
            else{
                $config=array(
                    'upload_path'=>'./upload/',
                    'allowed_types'=>'jpg|jpeg|png|JPEG|JPG|PNG'
                );
                $this->upload->initialize($config);
                $this->upload->do_upload('avatar');
                $avatar=$this->upload->data('file_name');

                if($_POST['status']=='Active'){
                    $stat=1;
                }
                else{
                    $stat=2;
                }

                $basicInfo=array(
                    'admin_fname'=>$_POST['fname'],
                    'admin_mname'=>$_POST['mname'],
                    'admin_lname'=>$_POST['lname'],
                    'admin_uname'=>$_POST['username'],
                    'admin_password'=>$_POST['password'],
                    'admin_email'=>$_POST['email'],
                    'admin_bdate'=>$_POST['bdate'],
                    'admin_gender'=>$_POST['gender'],
                    'admin_housenum'=>$_POST['housenum'],
                    'admin_street'=>$_POST['street'],
                    'admin_subdivision'=>$_POST['subdivision'],
                    'admin_contactnum'=>$_POST['contact'],
                    'admin_accStatus'=>$stat,
                    'admin_image'=>$avatar,
                    'admin_createdate'=>date('Y-m-d H:i:s'),
                );

                $this->db->insert('admin_tbl',$basicInfo);
                $this->load->view('admin/User_Management');
                // echo '<pre>';
                // print_r($basicInfo);
            }
        }

        public function deleteAdmin(){
            $condition=array(
                'admin_id'=>$this->uri->segment(3),
            );
            $data=array(
                'alluser'=> $this->vaccModel->getUserAccounts(),
                'alladmin'=> $this->vaccModel->getAdminAccounts(),
            );
            $this->db->where($condition);
            $this->db->delete('admin_tbl');
            $this->session->set_flashdata('admin_deleted');
            $this->load->view('admin/User_Management',$data);
        }


        public function AddUserAccount(){
            $this->load->view('admin/Add_Admin');
        }

        //resident
        public function viewResidentDashboard(){
            $this->load->view('resident/Dashboard');
        }

        public function viewResidentProfile(){
            $this->load->view('resident/Profile'); 
        }

        public function viewResident(){
            $data=array(
                'userId'=>$this->vaccModel->getAccountDetailsById('account_tbl','account_id',$this->uri->segment(3))
            );
            // print_r($data);
            $this->load->view('admin/viewResidentAccount',$data);
        }

        public function approveResident(){
            $id=array(
                'account_approvalStat'=>1
            );
            $data=array(
                'alluser'=> $this->vaccModel->getUserAccounts(),
                'alladmin'=> $this->vaccModel->getAdminAccounts(),
            );
            $this->db->update('account_tbl',$id,array('account_id'=>$this->uri->segment(3)));
            $this->db->insert('vaccination_tbl',array('vaccination_resid'=>$this->uri->segment(3)));
            // echo '<pre>';
        //    print_r($this->vaccModel->getAccountDetailsById('account_tbl','account_id',$this->uri->segment(3)));


            $this->load->view('admin/User_Management',$data);

        }
        public function confirmEditResident(){

            if($_POST['appstatus']=='Approved'){
                $app=1;
            }
            elseif($_POST['appstatus']=='Denied'){
                $app=2;
            }
            else{
                $app=3;
            }

            if($_POST['accstatus']=='Active'){
                $acc=1;
            }
            else{
                $acc=2;
            }

            $basicInfo=array(
                'account_fname'=>$_POST['fname'],
                'account_mname'=>$_POST['mname'],
                'account_lname'=>$_POST['lname'],
                'account_bdate'=>$_POST['birthdate'],
                'account_gender'=>$_POST['gender'],
                'account_housenum'=>$_POST['housenum'],
                'account_street'=>$_POST['street'],
                'account_subdivision'=>$_POST['subdivision'],
                'account_email'=>$_POST['email'],
                'account_contactnum'=>$_POST['contact'],
                'account_approvalStat'=>$app,
                'account_status'=>$acc,
                'account_id'=>$_POST['uid']
            );
            $data=array(
                'alluser'=> $this->vaccModel->getUserAccounts(),
                'alladmin'=> $this->vaccModel->getAdminAccounts(),
            );

            // echo "<pre>";
            // print_r($basicInfo);
            $this->db->where('account_id',$_POST['uid']);
            $this->db->update('account_tbl',$basicInfo);

            $this->load->view('admin/User_Management',$data);
        }
        
        public function editResident(){

            $data=array(
                'userId'=>$this->vaccModel->getAccountDetailsById('account_tbl','account_id',$this->uri->segment(3)),
                'accountstat'=>$this->vaccModel->getAccountStatus(),
                'approvalstat'=>$this->vaccModel->getApprovalStatus(),
            );
            $this->load->view('admin/editResidentAccount',$data); 
            // echo "<pre>";
            // print_r($data);
        }

        public function deleteResident(){
            $data=array(
                'account_id'=>$this->uri->segment(3),
            );
            $this->db->where($data);
            $this->db->delete('account_tbl');
            $this->session->set_flashdata('resident_deleted');
            $this->load->view('admin/User_Management');
        }

        // LIEZYL

        public function viewProfile(){
            $uname=$this->session->username;
            $pass=$this->session->password;

            $data=array(
                'information'=>$this->vaccModel->getAccountDetails('admin_tbl','admin_uname',$uname,'admin_password',$pass),
            );

            $this->load->view('admin/Profile',$data);

            // echo $uname;
            // echo $pass;
        }






        
    }

