<?php
class Viewrecord extends CI_Controller{
    public function index(){    
        $this->load->library('session');    
        $this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');
        $this->load->helper('url');
        $this->load->model('viewrecord_model');
        $data['records'] = $this->viewrecord_model->get_record();
        $data['vax_records'] = $this->viewrecord_model->get_vax_record();
        $data['stats'] = $this->viewrecord_model->get_stat();
        $this->load->view('admin/viewrecord',$data);
        
    }
    public function fvaxinfo($error=''){
        $firstvaxinfo = array(
            'vaccination_brand'=>$_POST['brand'],
            'vaccination_firstsched'=>$_POST['fsched'],
            'vaccination_firstStatus'=>$_POST['fstat'],
            'vaccination_fLotNumber'=>$_POST['flot'],
            'vaccination_fAdminId'=>$_POST['fadmin']            
        );
        $this->db->update('vaccination_tbl', $firstvaxinfo);
       // $this->allrecord;
        redirect("allrecord");
    }
    public function svaxinfo($error=''){
        $secondvaxinfo = array(
            'vaccination_secsched'=>$_POST['ssched'],
            'vaccination_secStatus'=>$_POST['sstat'],
            'vaccination_sAdminId'=>$_POST['sadmin'],
            'vaccination_sLotNumber'=>$_POST['slot']
        );
        $this->db->update('vaccination_tbl', $secondvaxinfo);
    }
}