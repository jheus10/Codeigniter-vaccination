<?php
class AllRecord extends CI_Controller{
    public function index(){    
        $this->load->library('session');
        $this->load->helper('url');
        $this->load->model('allrecord_model');
        $data['records'] = $this->allrecord_model->get_record();
        
        $this->load->view('admin/allrecord',$data);
    }
}