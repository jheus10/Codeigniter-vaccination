<?php
class Viewresrecord extends CI_Controller{
    public function index(){    
        $this->load->library('session');    
        $this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');
        $this->load->helper('url');
        $this->load->model('viewrecord_model');
        $data['records'] = $this->viewrecord_model->get_res_record();
        $data['vax_records'] = $this->viewrecord_model->get_res_vax_record();
        $data['stats'] = $this->viewrecord_model->get_stat();
        $this->load->view('resident/viewresrecord',$data);
    }
}