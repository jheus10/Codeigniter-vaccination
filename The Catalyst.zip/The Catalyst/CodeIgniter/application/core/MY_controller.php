<?php
    class MY_controller extends CI_Controller{
        public static function  mySampleMethod(){
            echo "sample method";
        }

        public function create_page($page, $arrayData=[]){
            $this->load->view('demo1/includes/header',$arrayData);
            $this->load->view('demo1/'.$page);
            $this->load->view('demo1/includes/footer');
        }
    }