<?php

$config=array(
    'protocol'=>"smtp",
    'smtp_host'=>'ssl://smtp.gmail.com',
    'smtp_user'=>"iturok571@gmail.com",
    'smtp_pass'=>'catalyst123',
    'smtp_port'=>465,
    'charset'=>'utf-8',
    'mailtype'=>'html',
    'newline'=>"\r\n",//need to be in double quote
);
