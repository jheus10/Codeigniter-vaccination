<!DOCTYPE html>
<html lang="en">

<head>

	<meta charset="utf-8" />
	<link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
	<link rel="icon" type="image/png" href="../assets/img/favicon.png">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	
	<title>User Profile</title>
	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
	<!--     Fonts and icons     -->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
	<link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
	  
	<!-- CSS Files -->
	<link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
	<link href="../assets/css/paper-dashboard.css?v=2.0.1" rel="stylesheet" />
	<!-- CSS Just for demo purpose, don't include it in your project -->
	<link href="../assets/demo/demo.css" rel="stylesheet" />
	
</head>

<body class="">
<div class="wrapper ">
    <div class="sidebar" data-color="white" data-active-color="danger">
      <div class="logo">
        <a  class="simple-text logo-mini" href="<?=base_url()?>Login_Controller/viewResidentProfile">
          <div class="logo-image-small">
            <img src="<?=base_url()?>assets/img/logo-small.png">
          </div>
          <!-- <p>CT</p> -->
        </a>
        <a class="simple-text logo-normal">
          Liezyl
        </a>
      </div>
      <div class="sidebar-wrapper">
        <ul class="nav">
          <li class="active ">
          
          <a href="<?=base_url()?>Login_Controller/viewResidentDashboard">
              <i class="nc-icon nc-bank"></i>
              <p>Dashboard</p>
            </a>
          </li>
         
               
        </ul>
      </div>
    </div>
		<div class="main-panel">
			<!-- Navbar -->
			<nav class="navbar navbar-expand-lg navbar-absolute fixed-top navbar-transparent">
				<div class="container-fluid">
					<div class="navbar-wrapper">
						<a class="navbar-brand" href="javascript:;">User Profile</a>
					</div>
				</div>
			</nav>
			
			<div class="content" style="line-height: 30px">
				<div class="row">
					<div class="col-sm-12">
						
						<div class="card card-user"><br>
							<div class="card-body">
								<a href="#">
									<center><h5 class="title">NOTICE: VACCINATION STATUS</h5></center>
								</a>
								<table style="width: 80%; margin-left: 80px;">
									<tr>
										<td>
											<img class="avatar border-gray" src="https://542partners.com.au/wp-content/uploads/2014/09/announcement-icon.png"
											style ="width: 150px; height: 150px;">
										</td>
										<td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp </td>
										
										<!-- NOTICE IF VACCINEE IS NOT YET SCHEDULED-->

										<td>
											<center>
											<p class="description" style="font-size: 25px">
												Your vaccination schedule is pending, <br> please wait for further announcement.
											</p>
											</center>
										</td>

										<!-- NOTICE IF VACCINEE IS SCHEDULED-->
										<!--
										<td>
											<center>
											<p class="description" style="font-size: 25px">
												You are now scheduled for vaccination! <br> Please refer to the vccination module <br> for further details.
											</p>
											</center>
										</td>
										-->	
										
									</tr>
								</table>
								<br>
							</div>	
						</div>
						
						<!-- VIEW: PERSONAL INFORMATION -->
						
						
						
						<div class="card card-user"><br>
							<div class="card-body">
								<a href="#">
									<center><h5 class="title">PERSONAL INFORMATION</h5></center>
								</a>
							
								
								<table style="width: 100%;">
									<tr>
										<td>
											<img class="avatar border-gray" src="https://thumbs.dreamstime.com/b/default-avatar-profile-icon-social-media-user-vector-default-avatar-profile-icon-social-media-user-vector-portrait-176194876.jpg"
											style ="width: 200px; height: 200px; ">
										</td>
										<td>
											<p class="description">
												<b>First Name: </b> John Ronel <br>
												<b>Middle Name: </b> Borja <br>
												<b>Last Name: </b> Ocampo <br>
												<b>Userame: </b> johnronelocampo <br>
												<b>Birthday: </b> 10-21-1999 <br>
												<b>Gender: </b> Male <br>
											</p>
										</td>
										<td>
											<p class="description">
												<b>Email: </b> johnocampo@gmail.com <br>
												<b>Contact Number: </b> 09153108816 <br>
												<b>House Number: </b> 1122 <br>
												<b>Street: </b> Amparo Street <br>
												<b>Subdivision: </b> Poblacion <br>
												<b>Priority Category: </b> Others <br>
											</p>
										</td>
									</tr>
								</table>
					
								<div class="update ml-auto mr-auto" style="float: right;">
									<button type="submit" class="btn btn-primary btn-round">Update Personal Information</button><br>
								</div>
							</div>	
						</div>
						
						
						<!-- EDIT: PERSONAL INFORMATION -->
						
						<!--
						
						<div class="card card-user"><br>
							<div class="card-body">
								<a href="#">
									<center><h5 class="title">EDIT PERSONAL INFORMATION</h5></center>
								</a>
								<center>
								<table style="width:80%;">
								
									<tr>
										<td>
											<div class="form-group">
												<label>First Name</label> <input type="text" class="form-control" name="fname" value="<?= set_value("fname");?>" required>
												<?php echo form_error('fname', '<div class="error mb-3">', '</div>'); ?>
											</div>
										</td>
										<td>&ensp;&ensp;&ensp;&ensp;&ensp;</td>
										<td>								
											<div class="form-group">
												<label>Email</label> <input type="text" class="form-control" name="email" value="<?= set_value("email");?>" required>
												<?php echo form_error('email', '<div class="error mb-3">', '</div>'); ?>
											</div>
										</td>
									</tr>
									
									<tr>
										<td>
											<div class="form-group">
												<label>Middle Name</label> <input type="text" class="form-control" name="mname" value="<?= set_value("mname");?>" required>
												<?php echo form_error('mname', '<div class="error mb-3">', '</div>'); ?>
											</div>
										</td>
										<td>&ensp;&ensp;&ensp;&ensp;&ensp;</td>
										<td>								
											<div class="form-group">
												<label>Contact Number</label> <input type="text" class="form-control" name="contact" value="<?= set_value("contact");?>" required>
												<?php echo form_error('contact', '<div class="error mb-3">', '</div>'); ?>
											</div>
										</td>
									</tr>
									
									<tr>
										<td>
											<div class="form-group">
												<label>Last Name</label> <input type="text" class="form-control" name="lname" value="<?= set_value("lname");?>" required>
												<?php echo form_error('lname', '<div class="error mb-3">', '</div>'); ?>
											</div>
										</td>
										<td>&ensp;&ensp;&ensp;&ensp;&ensp;</td>
										<td>								
											<div class="form-group">
												<label>House Number</label> <input type="text" class="form-control" name="housenum" value="<?= set_value("housenum");?>" required>
												<?php echo form_error('housenum', '<div class="error mb-3">', '</div>'); ?>
											</div>
										</td>
									</tr>
									
									<tr>
										<td>
											<div class="form-group">
												<label>Username</label> <input type="text" class="form-control" name="username" value="<?= set_value("username");?>" required>
												<?php echo form_error('username', '<div class="error mb-3">', '</div>'); ?>
											</div>
										</td>
										<td>&ensp;&ensp;&ensp;&ensp;&ensp;</td>
										<td>								
											<div class="form-group">
												<label>Street</label> <input type="text" class="form-control" name="street" value="<?= set_value("street");?>" required>
												<?php echo form_error('street', '<div class="error mb-3">', '</div>'); ?>
											</div>
										</td>
									</tr>
									
									<tr>
										<td>
											<div class="form-group">
												<label>Birthday</label> <input type="date" class="form-control" name="birthdate" value="<?= set_value("birthdate");?>" required>
												<?php echo form_error('birthdate', '<div class="error mb-3">', '</div>'); ?>
											</div>
										</td>
										<td>&ensp;&ensp;&ensp;&ensp;&ensp;</td>
										<td>								
											<div class="form-group">
												<label>Subdivision</label> <input type="text" class="form-control" name="subdivision" value="<?= set_value("subdivision");?>" required>
												<?php echo form_error('subdivision', '<div class="error mb-3">', '</div>'); ?>
											</div>
										</td>
									</tr>
									
									<tr>
										<td>
											<div class="form-group">
												<label>Gender</label>
												<input list="gender" class="form-control" name="gender">
												<datalist  id="gender" name="gender" id="genderSelect" required>
													<option value="Male"></option>
													<option value="Female"></option>
												</datalist>
											</div>
										</td>
										<td>&ensp;&ensp;&ensp;&ensp;&ensp;</td>
										<td>								
											<div class="form-group">
												<label>Priority Category</label> 
												<select  type="text" class="form-control" name="priorityCateg" id="categSelect" required>
													<?php foreach($category as $categ):?>
														<option value="<?=$categ->priority_id?>" selected>
															<?=$categ->priority_category?>
														</option>
													<?php endforeach;?>  
												</select>
											</div>
										</td>
									</tr>
						
								</table>
									
								</center>
									<td><label style="margin-left:92px">Avatar&ensp;&ensp;&ensp;</label></td> 
									<td><input type="file" id="account_image" name="accountimage" value="<?= set_value("account_image");?>" required></td>
								
								<div class="update ml-auto mr-auto" style="float: right;">
									<button type="cancel" class="btn btn-light btn-round">Cancel</button>
									<button type="submit" class="btn btn-primary btn-round">Save Changes</button><br>
									
								</div>
							</div>	
						</div>
						
						-->
						
						<!-- VIEW: HEALTH INFORMATION -->
						
						
						
						<div class="card card-user"> <br>
							<div class="card-body">
								<a href="#">
									<center><h5 class="title">HEALTH INFORMATION</h5></center>
								</a>
								<table style="width: 90%; margin-left: 30px;">
									<tr>
										<td>
											<p class="description">
												<b> TYPE OF COMORBIDITY: </b> <br>
												<div class="description" style="margin-left: 75px";>
													<b>Allergies: </b> <br>
													<b>Diseases: </b> <br>
													<b>Diabetic: </b> <br>
													<b>Hypertension: </b> <br>
													<b>Organ Transplant: </b> <br>
												</div>
											</p>
										</td>
										<td>
											<p class="description">
												<b>&nbsp </b> <br>
												<div class="description" style="margin-left: 75px";>
													No <br>
													No <br>
													No <br>
													No <br>
													No <br>
												</div>
											</p>
										</td>
										<td> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp </td>
										<td><br>
											<p class="description">
												<b> COVID-19 SYMPTOMS: </b> <br>
												<div class="description" style="margin-left: 75px";>
													<b>Fever: </b> <br>
													<b>Cough: </b> <br>
													<b>Body Pain: </b> <br>
													<b>Shortness of Breath: </b> <br>
													<b>Lost of Taste/Smell: </b> <br>
													<b>Diarrhea: </b> <br>	
												</div>
											</p>
										</td>
										<td>
											<p class="description">
												<b>&nbsp </b> <br><br>
												<div class="description" style="margin-left: 75px";>
													No <br>
													No <br>
													No <br>
													No <br>
													No <br>
													No <br>
												</div>
											</p>
										</td>
									</tr>
								</table>
								
								<div class="update ml-auto mr-auto" style="float: right;">
								<br>
									<button type="submit" class="btn btn-primary btn-round">Update Health Information</button>
								</div>
							</div>	
						</div>
						
						
						
						<!-- EDIT: HEALTH INFORMATION -->
						
						<!--

						<div class="card card-user"> <br>
							<div class="card-body">
								<a href="#">
									<center><h5 class="title">HEALTH INFORMATION</h5></center>
								</a>
								<table style="width: 90%; margin-left: 20px;">
									<tr>
										<td>
											<p class="description">
												<b> TYPE OF COMORBIDITY: </b> <br>
												<div class="description" style="margin-left: 75px";>
													<b>Allergies: </b> <br>
													<b>Diseases: </b> <br>
													<b>Diabetic: </b> <br>
													<b>Hypertension: </b> <br>
													<b>Organ Transplant: </b> <br>
												</div>
											</p>
										</td>
										<td>
											<p class="description">
												 <br>
												<div class="description" style="margin-left: 40px; line-height: 26px">
													<input type="radio" id="radioAllergy1" name="radioAllergy" value="Yes">
													<label for="radioAllergy1">&ensp;&ensp;Yes</label><br>
													<input type="radio" id="radioDiseases1" name="radioDiseases" value="Yes">
													<label for="radioDiseases1">&ensp;&ensp;Yes</label><br>
													<input type="radio" id="radioDiabetic1" name="radioDiabetic" value="Yes">
													<label for="radioDiabetic1">&ensp;&ensp;Yes</label><br>
													<input type="radio" id="radioHypertension1" name="radioHypertension" value="Yes">
													<label for="radioHypertension1">&ensp;&ensp;Yes</label><br>
													<input type="radio" id="radioOrgan1" name="radioOrgan" value="Yes">
													<label for="radioOrgan1">&ensp;&ensp;Yes</label>
												</div>
											</p>
										</td>
										<td>
											<p class="description">
												 <br>
												<div class="description" style="margin-left: 40px; line-height: 26px">
													<input type="radio" id="radioAllergy2" name="radioAllergy" value="No">
													<label for="radioAllergy2">&ensp;&ensp;No</label><br>
													<input type="radio" id="radioDiseases2" name="radioDiseases" value="No">
													<label for="radioDiseases2">&ensp;&ensp;No</label><br>
													<input type="radio" id="radioDiabetic2" name="radioDiabetic" value="No">
													<label for="radioDiabetic2">&ensp;&ensp;No</label><br>
													<input type="radio" id="radioHypertension2" name="radioHypertension" value="No">
													<label for="radioHypertension2">&ensp;&ensp;No</label><br>
													<input type="radio" id="radioOrgan2" name="radioOrgan" value="No">
													<label for="radioOrgan2">&ensp;&ensp;No</label>
												</div>
											</p>
										</td>
										<td> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp </td>
										<td><br>
											<p class="description">
												<b> COVID-19 SYMPTOMS: </b> <br>
												<div class="description" style="margin-left: 75px";>
													<b>Fever: </b> <br>
													<b>Cough: </b> <br>
													<b>Body Pain: </b> <br>
													<b>Shortness of Breath: </b> <br>
													<b>Lost of Taste/Smell: </b> <br>
													<b>Diarrhea: </b> <br>	
												</div>
											</p>
										</td>
										<td>
											<p class="description">
												<br><br>
												<div class="description" style="margin-left: 40px; line-height: 26px">
													<input type="radio" id="radioFever1" name="radioFever" value="Yes">
													<label for="radioFever1">&ensp;&ensp;Yes</label><br>
													<input type="radio" id="radioCough1" name="radioCough" value="Yes">
													<label for="radioCough1">&ensp;&ensp;Yes</label><br>
													<input type="radio" id="radioBodyPain1" name="radioBodyPain" value="Yes">
													<label for="radioBodyPain1">&ensp;&ensp;Yes</label><br>
													<input type="radio" id="radioBreath1" name="radioBreath" value="Yes">
													<label for="radioBreath1">&ensp;&ensp;Yes</label><br>
													<input type="radio" id="radioTaste1" name="radioTaste" value="Yes">
													<label for="radioTaste1">&ensp;&ensp;Yes</label><br>
													<input type="radio" id="radioDiarrhea1" name="radioDiarrhea" value="Yes">
													<label for="radioDiarrhea1">&ensp;&ensp;Yes</label>
												</div>
											</p>
										</td>
										<td>
											<p class="description">
												<br><br>
												<div class="description" style="margin-left: 40px; line-height: 26px">
													<input type="radio" id="radioFever2" name="radioFever" value="No" >
													<label for="radioFever2">&ensp;&ensp;No</label><br>
													<input type="radio" id="radioCough2" name="radioCough" value="No">
													<label for="radioCough2">&ensp;&ensp;No</label><br>
													<input type="radio" id="radioBodyPain2" name="radioBodyPain" value="No">
													<label for="radioBodyPain2">&ensp;&ensp;No</label><br>
													<input type="radio" id="radioBreath2" name="radioBreath" value="No">
													<label for="radioBreath2">&ensp;&ensp;No</label><br>
													<input type="radio" id="radioTaste2" name="radioTaste" value="No">
													<label for="radioTaste2">&ensp;&ensp;No</label><br>
													<input type="radio" id="radioDiarrhea2" name="radioDiarrhea" value="No">
													<label for="radioDiarrhea2">&ensp;&ensp;No</label>
												</div>
											</p>
										</td>
									</tr>
								</table>
								
								<div class="update ml-auto mr-auto" style="float: right;">
								<br>
									<button type="cancel" class="btn btn-light btn-round">Cancel</button>
									<button type="submit" class="btn btn-primary btn-round">Save Changes</button>
								</div>
							</div>	
						</div>
						
						-->
						
						<!--PASSWORD SETTINGS-->
						
						
						
						<div class="card card-user"> <br>
							<div class="card-body">
								<a href="#">
									<center><h5 class="title">PASSWORD SETTINGS</h5></center>
								</a>
								
								<br><center>
								<p class="description">
									To be able to change the account password, please click the button on the lower right corner of the card.
								</p>
								<br></center>
										
								
								<div class="update ml-auto mr-auto" style="float: right;">
									<button type="submit" class="btn btn-primary btn-round">Change Password</button>
								</div>
							</div>	
						</div>
						
						
						
						<!--CHANGE PASSWORD-->
						
						<!--
						
						<div class="card card-user"> <br>
							<div class="card-body">
								<a href="#">
									<center><h5 class="title">PASSWORD SETTINGS</h5></center>
								</a>
								
								<center>
								
								<div class="form-group" style="width: 40%; text-align: left">
									<label>Old Password</label> <input type="password" class="form-control">
									<label>New Password</label> <input type="password" class="form-control">
									<label>Confirm New Password</label> <input type="password" class="form-control">
								</div>
								
								<br></center>
										
								
								<div class="update ml-auto mr-auto" style="float: right;">
									<button type="cancel" class="btn btn-light btn-round">Cancel</button>
									<button type="submit" class="btn btn-primary btn-round">Save Changes</button>
								</div>
							</div>	
						</div>
						
						-->
						
					</div>
		</div>
	</div>
	
	<!--   Core JS Files   -->
	<script src="../assets/js/core/jquery.min.js"></script>
	<script src="../assets/js/core/popper.min.js"></script>
	<script src="../assets/js/core/bootstrap.min.js"></script>
	<script src="../assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
	<!--  Google Maps Plugin    -->
	<script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
	<!-- Chart JS -->
	<script src="../assets/js/plugins/chartjs.min.js"></script>
	<!--  Notifications Plugin    -->
	<script src="<../assets/js/plugins/bootstrap-notify.js"></script>
	<!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
	<script src="../assets/js/paper-dashboard.min.js?v=2.0.1" type="text/javascript"></script><!-- Paper Dashboard DEMO methods, don't include it in your project! -->
	<script src="<../assets/demo/demo.js"></script>
	
	<script>
		$(document).ready(function(){
	 	 $(".first-fourth").hide();
		  $(".second").hide();
		  $(".third").hide();
		  $(".fifth").hide();

		$('#categSelect').on('change', function(){
			
		    var value = $(this).val();
			$('div.suppDocs').hide();
		    if (value == '1'||value == '4') {
		        $(".first-fourth").show();
				$(".others").hide();
				$(".second").hide();
				$(".third").hide();
				$(".fifth").hide();
		    } 
		    else if (value == '2') {
		        $(".second").show();
				$(".others").hide();
				$(".first-fourth").hide();
				$(".third").hide();
				$(".fifth").hide();
		    }
			else if (value == '3') {
		        $(".third").show();
				$(".others").hide();
				$(".first-fourth").hide();
				$(".second").hide();
				$(".fifth").hide();
		    }
			else if (value == '5') {
		        $(".fifth").show();
				$(".others").hide();
				$(".first-fourth").hide();
				$(".second").hide();
				$(".third").hide();
		    }
			else if (value == '6') {
		        $(".others").show();
				$(".fifth").hide();
				$(".first-fourth").hide();
				$(".second").hide();
				$(".third").hide();
		    }
			else{
				$(".others").show();
				$(".fifth").hide();
				$(".first-fourth").hide();
				$(".second").hide();
				$(".third").hide();
			}
		});
		
	});

	</script>
</body>

</html>