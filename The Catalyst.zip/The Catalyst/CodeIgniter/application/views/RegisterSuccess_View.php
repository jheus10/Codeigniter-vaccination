<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Success</title>
</head>
<body>

<script type="text/javascript">
    alert("Account successfully created! Please verify your account before logging in");
    window.location.href = "<?=base_url()?>login_controller";
</script>

</body>
</html>