<!DOCTYPE html>
<html lang="en">

<head>

	<meta charset="utf-8" />
	<link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
	<link rel="icon" type="image/png" href="../assets/img/favicon.png">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	
	<title>User Profile</title>
	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
	<!--     Fonts and icons     -->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
	<link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
	  
	<!-- CSS Files -->
	<link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
	<link href="../assets/css/paper-dashboard.css?v=2.0.1" rel="stylesheet" />
	<!-- CSS Just for demo purpose, don't include it in your project -->
	<link href="../assets/demo/demo.css" rel="stylesheet" />
	
</head>

<body class="">
<div class="wrapper ">
    <div class="sidebar" data-color="white" data-active-color="danger">
      <div class="logo">
        <a class="simple-text logo-mini" href="<?=base_url('Login_Controller/viewAdminProfile')?>">
          <div class="logo-image-small">
            <img src="<?=base_url('assets/img/logo-small.png')?>">
          </div>
          <!-- <p>CT</p> -->
        </a>
        <a class="simple-text logo-normal row">
              <?=$this->session->fname;?>
              <!-- <a type="button" href="<?=base_url('Login_Controller/logout')?>"><i class="nc-icon nc-button-power"></i></a> -->
              <!-- <button class="btn btn-primary btn-fab btn-icon btn-round" type="button" href="<?=base_url()?>Login_Controller/logout"><i class="nc-icon nc-button-power"></i><button> -->
          </a>
      </div>
      <div class="sidebar-wrapper">
        <ul class="nav">
          <li >
            <a href="<?=base_url('Login_Controller/DisplayAccount')?>">
              <i class="nc-icon nc-bank"></i>
              <p>Dashboard</p>
            </a>
          </li>
          <li class="active" >
            <a href="<?=base_url('Login_Controller/viewAdminProfile')?>">
              <i class="nc-icon nc-circle-10"></i>
              <p>User Profile</p>
            </a>
          </li>
          <li >
            <a href="<?=base_url('allrecord')?>">
              <i class="nc-icon nc-bullet-list-67"></i>
              <p>Vaccination</p>
            </a>
          </li>
          <li >
            <a href="<?=base_url('Login_Controller/UserManagement')?>">
              <i class="nc-icon nc-tile-56"></i>
              <p>User Management</p>
            </a>
          </li>
        </ul>
      </div>
      </div>
      <div class="main-panel">
      <!-- Navbar -->
        <nav class="navbar navbar-expand-lg navbar-absolute fixed-top navbar-transparent">
          <div class="container-fluid">
            <div class="navbar-wrapper">
              <div class="navbar-toggle">
                <button type="button" class="navbar-toggler">
                  <span class="navbar-toggler-bar bar1"></span>
                  <span class="navbar-toggler-bar bar2"></span>
                  <span class="navbar-toggler-bar bar3"></span>
                </button>
              </div>
              <div>
                <a class="navbar-brand" href="javascript:;">Noveleta Cavite</a>
                <a href="<?= base_url('Login_Controller/logout');?>">
                  <button type="submit" class="btn btn-primary btn-round" style="position: absolute; right: 10px">Logout</button>
                </a>
              </div>
            </div>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navigation" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-bar navbar-kebab"></span>
              <span class="navbar-toggler-bar navbar-kebab"></span>
              <span class="navbar-toggler-bar navbar-kebab"></span>
            </button>
          </div>
        </nav>
      <!-- End Navbar -->
			
			<div class="content" style="line-height: 30px">
				<div class="row">
					<div class="col-sm-12">
						
						
						<!-- VIEW: PERSONAL INFORMATION -->
						
						
						
						<div class="card card-user"><br>
							<div class="card-body">
								<a href="#">
									<center><h5 class="title">PERSONAL INFORMATION</h5></center>
								</a>
							
								<?php
									foreach($information as $result){
								?>
								
								<table style="width: 100%;">
									<tr>
										<td>
											<img class="avatar border-gray" src="https://thumbs.dreamstime.com/b/default-avatar-profile-icon-social-media-user-vector-default-avatar-profile-icon-social-media-user-vector-portrait-176194876.jpg"
											style ="width: 200px; height: 200px; ">
										</td>
										<td>
											<p class="description">
												<b>Admin ID: </b> 911<br>
												<b>First Name: </b> John Ronel <br>
												<b>Middle Name: </b> Borja <br>
												<b>Last Name: </b> Ocampo <br>
												<b>Userame: </b> johnronelocampo <br>
											</p>
										</td>
										<td>
											<p class="description">
												<b>Email: </b> johnocampo@gmail.com <br>
												<b>Contact Number: </b> 09153108816 <br>
												<b>Date Created: </b> 1122 <br>
												<b>Account Status: </b> Ewan <br>
												&nbsp
											</p>
										</td>
									</tr>
								</table>
					
								<div class="update ml-auto mr-auto" style="float: right;">
									<button type="submit" class="btn btn-primary btn-round">Update Personal Information</button><br>
								</div>
							</div>	
						</div>
						<?php
						}
						?>
						
						<!-- EDIT: PERSONAL INFORMATION -->
						
						<div class="card card-user"><br>
							<div class="card-body">
								<a href="#">
									<center><h5 class="title">EDIT PERSONAL INFORMATION</h5></center>
								</a>
								<center>
								<table style="width:80%;">
								
									<tr>
										<td>
											<div class="form-group">
												<label>Admin ID</label> <input type="text" class="form-control" disabled>
											</div>
										</td>
										<td>&ensp;&ensp;&ensp;&ensp;&ensp;</td>
										<td>								
											<div class="form-group">
												<label>Email</label> <input type="text" class="form-control" required>
											</div>
										</td>
									</tr>
									
									<tr>
										<td>
											<div class="form-group">
												<label>First Name</label> <input type="text" class="form-control" required>
											</div>
										</td>
										<td>&ensp;&ensp;&ensp;&ensp;&ensp;</td>
										<td>								
											<div class="form-group">
												<label>Contact Number</label> <input type="text" class="form-control" required>
											</div>
										</td>
									</tr>
									
									<tr>
										<td>
											<div class="form-group">
												<label>Middle Name</label> <input type="text" class="form-control" required>
											</div>
										</td>
										<td>&ensp;&ensp;&ensp;&ensp;&ensp;</td>
										<td>								
											<div class="form-group">
												<label>Date Created</label> <input type="date" class="form-control" disabled>
											</div>
										</td>
									</tr>
									
									<tr>
										<td>
											<div class="form-group">
												<label>Last Name</label> <input type="text" class="form-control" required>
											</div>
										</td>
										<td>&ensp;&ensp;&ensp;&ensp;&ensp;</td>
										<td>								
											<div class="form-group">
												<label>Account Status</label> <input type="text" class="form-control" required>
											</div>
										</td>
									</tr>
									
									<tr>
										<td>
											<div class="form-group">
												<label>Username</label> <input type="date" class="form-control" required>
											</div>
										</td>
									</tr>
						
								</table>
									
								</center>
								
								<br><label style="margin-left:92px">Avatar</label> <input type="file" id="valid_id" name="valid_id" required><br>
								
								<div class="update ml-auto mr-auto" style="float: right;">
									<button type="cancel" class="btn btn-light btn-round">Cancel</button>
									<button type="submit" class="btn btn-primary btn-round">Save Changes</button><br>
								</div>
							</div>	
						</div>
						
						<!--PASSWORD SETTINGS-->
						
						
						
						<div class="card card-user"> <br>
							<div class="card-body">
								<a href="#">
									<center><h5 class="title">PASSWORD SETTINGS</h5></center>
								</a>
								
								<br><center>
								<p class="description">
									To be able to change the account password, please click the button on the lower right corner of the card.
								</p>
								<br></center>
										
								
								<div class="update ml-auto mr-auto" style="float: right;">
									<button type="submit" class="btn btn-primary btn-round">Change Password</button>
								</div>
							</div>	
						</div>
						
						
						
						<!--CHANGE PASSWORD-->
						
					
						
						<div class="card card-user"> <br>
							<div class="card-body">
								<a href="#">
									<center><h5 class="title">PASSWORD SETTINGS</h5></center>
								</a>
								
								<center>
								
								<div class="form-group" style="width: 40%; text-align: left">
									<label>Old Password</label> <input type="password" class="form-control">
									<label>New Password</label> <input type="password" class="form-control">
									<label>Confirm New Password</label> <input type="password" class="form-control">
								</div>
								
								<br></center>
										
								
								<div class="update ml-auto mr-auto" style="float: right;">
									<button type="cancel" class="btn btn-light btn-round">Cancel</button>
									<button type="submit" class="btn btn-primary btn-round">Save Changes</button>
								</div>
							</div>	
						</div>
						
						
					</div>
		</div>
	</div>
	
	<!--   Core JS Files   -->
	<script src="../assets/js/core/jquery.min.js"></script>
	<script src="../assets/js/core/popper.min.js"></script>
	<script src="../assets/js/core/bootstrap.min.js"></script>
	<script src="../assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
	<!--  Google Maps Plugin    -->
	<script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
	<!-- Chart JS -->
	<script src="../assets/js/plugins/chartjs.min.js"></script>
	<!--  Notifications Plugin    -->
	<script src="../assets/js/plugins/bootstrap-notify.js"></script>
	<!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
	<script src="../assets/js/paper-dashboard.min.js?v=2.0.1" type="text/javascript"></script><!-- Paper Dashboard DEMO methods, don't include it in your project! -->
	<script src="../assets/demo/demo.js"></script>
</body>

</html>