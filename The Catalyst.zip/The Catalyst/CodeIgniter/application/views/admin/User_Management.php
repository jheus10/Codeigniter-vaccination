<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="<?=base_url()?>assets/img/apple-icon.png">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>
    
  </title>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
  <!--     Fonts and icons     -->
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
  <!-- CSS Files -->
  <link href="<?=base_url()?>assets/css/bootstrap.min.css" rel="stylesheet" />
  <link href="<?=base_url()?>assets/css/paper-dashboard.css?v=2.0.1" rel="stylesheet" />
  <!-- CSS Just for demo purpose, don't include it in your project -->
  <link href="<?=base_url()?>assets/demo/demo.css" rel="stylesheet" />
  <style>
		@import url('https://fonts.googleapis.com/css?family=Poppins');

/*basic reset*/
* {margin: 0; padding: 0;}

html {
  background: linear-gradient(0deg, rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), 
    url(https://cloudfront-us-east-2.images.arcpublishing.com/reuters/NS32IE6UUBKUFDTNRBMSYMUPKA.jpg) 
    no-repeat center center fixed; 
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;
}

body {
  height: 100%;
  font-family: "Poppins", sans-serif;
  height: 100vh;
}

		/*form styles*/
		#msform {
			width: 450px;
			margin: 50px auto;
			text-align: center;
			position: relative;
		}
		
		#msform fieldset {
			background: white;
			border: 0 none;
			border-radius: 10px 10px 10px 10px;
			box-shadow: 0 0 15px 1px rgba(0, 0, 0, 0.4);
			padding: 30px;
			box-sizing: border-box;
			width: 500px;
			/*stacking fieldsets above each other*/
			margin-left: -20px;
			position: relative;
		}
		
		/*Hide all except first fieldset*/
		#msform fieldset:not(:first-of-type) {
			display: none;
		}
		
		/*inputs*/
		#msform input, #msform textarea {
			padding: 10px;
			border: 1px solid #ccc;
			border-radius: 3px;
			margin-bottom: 10px;
			width: 100%;
			box-sizing: border-box;
			font-family: "Poppins", sans-serif;
			color: black;
			font-size: 13px;
			border: 2px solid #ececec;
		}
		
		input[type=text]:focus {
			background-color: #fff;
			border-bottom: 2px solid #5fbae9;
		}
		
		input[type=text]:placeholder {
			color: #cccccc;
		}
		
		
		input[type=button], input[type=submit], input[type=reset]  {
			width: 30% !important;
			background-color: #56baed;
			border: none !important;
			color: white !important;
			padding: 15px 80px;
			text-align: center;
			text-decoration: none;
			display: inline-block;
			text-transform: uppercase;
			font-size: 13px;
			-webkit-box-shadow: 0 10px 30px 0 rgba(95,186,233,0.4);
			box-shadow: 0 10px 30px 0 rgba(95,186,233,0.4);
			-webkit-border-radius: 5px 5px 5px 5px;
			border-radius: 5px 5px 5px 5px;
			-webkit-transition: all 0.3s ease-in-out;
			-moz-transition: all 0.3s ease-in-out;
			-ms-transition: all 0.3s ease-in-out;
			-o-transition: all 0.3s ease-in-out;
			transition: all 0.3s ease-in-out;
		}
		
		input[type=button]:hover, input[type=submit]:hover, input[type=reset]:hover  {
			background-color: #39ace7;
		}
		
		input[type=button]:active, input[type=submit]:active, input[type=reset]:active  {
			-moz-transform: scale(0.95);
			-webkit-transform: scale(0.95);
			-o-transform: scale(0.95);
			-ms-transform: scale(0.95);
			transform: scale(0.95);
		}	

    .checkboxes {
			display: flex;
			justify-content: center;
			align-items: top;
			vertical-align: center;
			word-wrap: break-word;
			margin-left: -13px;
			margin-top: 5px;
		}


    .close {
      color: dodgerblue;
      float: right;
      font-size: 1rem;
      font-weight: bold;
      background-color: #51cbce;
      border: none;
      padding: 12px 20px;
    }
    #admin-card{
      box-shadow:none;
    }
</style>

  <script>

	function deleteAdmin() {
		delAdmin_btn=document.querySelectorAll('.delAdmin')
        delAdmin_btn.forEach(onebyone => {
            onebyone.addEventListener('click',delete_admin)
        })
      function delete_admin(){
			var adminid_delete = this.id;
			// var id=itm_id_edit ;
			// console.log(itm_id_edit);
			var status=confirm("Are you sure to delete this account?");
	    	if (status==true){ 
				window.location.href="http://localhost/CodeIgniter/Login_Controller/deleteAdmin/"+adminid_delete;
			}
			else{
	    		alert("Account deletion cancelled");
	    		window.location.href="http://localhost/CodeIgniter/Login_Controller/UserManagement";
	    	}
		}
	}
  function deleteResident(){
		delResident_btn=document.querySelectorAll('.delResident')
        delResident_btn.forEach(onebyone => {
            onebyone.addEventListener('click',delete_resident)
        })
      function delete_resident(){
			var resid_delete = this.id;
			var status=confirm("Are you sure to delete this account ?");
	    	if (status==true){ 
				window.location.href="http://localhost/CodeIgniter/Login_Controller/deleteResident/"+resid_delete;
			}
			else{
	    		alert("Account deletion cancelled");
	    		window.location.href="http://localhost/CodeIgniter/Login_Controller/UserManagement";
	    	}
		}
	}

  function approveResident(){
		appResident_btn=document.querySelectorAll('.appResident')
        appResident_btn.forEach(onebyone => {
            onebyone.addEventListener('click',approve_resident)
        })
      function approve_resident(){
			var resid_approve = this.id;
			var status=confirm("Are you sure to approve this account?");
	    	if (status==true){ 
				window.location.href="http://localhost/CodeIgniter/Login_Controller/approveResident/"+resid_approve;
			}
			else{
	    		alert("Account approval cancelled");
	    		window.location.href="http://localhost/CodeIgniter/Login_Controller/UserManagement";
	    	}
		}
	}

  
  </script>
</head>

<div class="modal" id="add-new-admin" data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
	        <div class="modal-header text-center">
	        	<h5 class="modal-title ">Add New</h5>
	           <button type="button" class="close" data-dismiss="modal">&times;</button>
	        </div>
	        <div class="modal-body">
          
          <div id="error-alert" class="alert hidden" role="alert"></div>
          <div id="admin-card" class="card card-user">
              <form id="form1" action="<?=base_url()?>Login_Controller/createAdminAccount" method="post" enctype="multipart/form-data">
                <div class="card-header">
                  <!-- <h5 class="card-title">Personal Information</h5> -->
                </div>

                  <div class="card-body">
                      <div class="row">
                        <div class="col-md-4 pr-1">
                          <div class="form-group">
                            <label>First Name</label>
                            <input type="text" name="fname" class="form-control" value="<?= set_value("fname");?>" required>
                            <font color="red"><?php echo form_error('fname', '<div class="error mb-3">', '</div>'); ?></font>
                            <!-- <div id="fname" class="alert hidden" role="alert"></div> -->
                          </div>
                        </div>

                        <div class="col-md-4 px-1">
                          <div class="form-group">
                            <label>Middle Name</label>
                            <input type="text" name="mname" class="form-control" value="<?= set_value("mname");?>" required>
                            <font color="red"><?php echo form_error('mname', '<div class="error mb-3">', '</div>'); ?></font>
                          </div>
                        </div>
                        <div class="col-md-4 pl-1">
                          <div class="form-group">
                            <label for="exampleInputEmail1">Last Name</label>
                            <input type="text" name="lname" class="form-control" value="<?= set_value("lname");?>" required>
                            <font color="red"><?php echo form_error('lname', '<div class="error mb-3">', '</div>'); ?></font>
                          </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-md-4 pr-1">
                          <div class="form-group">
                            <label>Birthdate</label>
                            <input type="date" name="bdate" class="form-control" value="<?= set_value("bdate");?>" required>
                            <font color="red"><?php echo form_error('bdate', '<div class="error mb-3">', '</div>'); ?></font>
                          </div>
                        </div>
                        <div class="col-md-4 px-1">
                          <div class="form-group">
                            <label>Contact Number</label>
                            <input type="text" class="form-control" name="contact" value="<?= set_value("contact");?>" required>
                            <font color="red"><?php echo form_error('contact', '<div class="error mb-3">', '</div>'); ?></font>
                          </div>
                        </div>
                        <div class="col-md-4 pl-1">
                          <div class="form-group">
                            <label>Gender</label>
                            <input list="gender"  class="form-control" name="gender" >
                              <datalist id="gender" name="gender" id="genderSelect" value="<?= set_value("gender");?>" required>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                              </datalist>
                          </div>
                        </div>

                        
                      </div>
                      <div class="row">
                        <div class="col-md-4 pr-1">
                          <div class="form-group">
                            <label>House Number</label>
                            <input type="text" class="form-control" name="housenum" value="<?= set_value("housenum");?>"  required>
                            <font color="red"><?php echo form_error('housenum', '<div class="error mb-3">', '</div>'); ?></font>
                          </div>
                        </div>
                        <div class="col-md-4 px-1">
                          <div class="form-group">
                            <label>Street</label>
                            <input type="text" class="form-control" name="street" value="<?= set_value("street");?>" required>
                            <font color="red"><?php echo form_error('street', '<div class="error mb-3">', '</div>'); ?></font>
                          </div>
                        </div>
                        <div class="col-md-4 pl-1">
                          <div class="form-group">
                            <label>Subdivision</label>
                            <input type="text" class="form-control" name="subdivision" value="<?= set_value("subdivision");?>" required>
                            <font color="red"><?php echo form_error('subdivision', '<div class="error mb-3">', '</div>'); ?></font>
                          </div>
                        </div>
                      </div>
      
                      <div class="row">
                        <div class="col-md-6 pr-1">
                          <div class="form-group">
                            <label>Username</label>
                            <input type="text" name="username" class="form-control" value="<?= set_value("username");?>" required>
                            <font color="red"><?php echo form_error('username', '<div class="error mb-3">', '</div>'); ?></font>
                          </div>
                        </div>
                        <div class="col-md-6 pl-1">
                          <div class="form-group">
                            <label>Email</label>
                            <input type="email" name="email" class="form-control" value="<?= set_value("email");?>" required>
                            <font color="red"><?php echo form_error('email', '<div class="error mb-3">', '</div>'); ?></font>
                          </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-md-6 pr-1">
                          <div class="form-group">
                            <label>Password</label>
                            <input type="password" name="password" class="form-control" value="<?= set_value("password");?>" required>
                            <font color="red"><?php echo form_error('password', '<div class="error mb-3">', '</div>'); ?></font>
                          </div>
                        </div>
                        <div class="col-md-6 pl-1">
                          <div class="form-group">
                            <label>Confirm Password</label>
                            <input type="password" name="passconf" class="form-control" value="<?= set_value("passconf");?>" required>
                            <font color="red"><?php echo form_error('passconf', '<div class="error mb-3">', '</div>'); ?></font>
                          </div>
                        </div>
                      </div>

                  <div class="row">
                          <div class="col-md-6 pr-1">
                            <div class="form-group">
                              <label>Status</label>
                              <input list="status" class="form-control" name="status">
                                <datalist id="status" name="status" id="statusSelect" value="<?= set_value("status");?>"  required>
                                  <option value="Active">Active</option>
                                  <option value="Deactivated">Deactivated</option>
                                </datalist>
                            </div>
                          </div>
                          <div class="col-md-6 pl-1">
                            <div class="form-group">
                              <label>Profile Picture</label>
                              <input type="file" id="avatar" name="avatar" value="<?= set_value("avatar");?>" required>
                            </div>
                          </div>
                  </div>
                      
                      <br>

                      <div class="row">
                        <div class="update ml-auto mr-auto">
                          <button type="submit" class="btn btn-primary btn-round" data-dismiss="modal">Cancel</button>
                          <a href="<?=base_url()?>Login_Controller/UserManagement"><button type="submit" id="sendForm"class="btn btn-primary btn-round">Submit</button></a>
                        </div>
                      </div>      
                  </div>
                </div>
              </form>
	        </div>
        </div>
    </div>
</div>



<body class="">
<div class="wrapper ">
    <div class="sidebar" data-color="white" data-active-color="danger">
      <div class="logo">
        <a class="simple-text logo-mini" href="<?=base_url()?>Login_Controller/viewAdminProfile">
          <div class="logo-image-small">
            <img src="<?=base_url()?>assets/img/logo-small.png">
          </div>
          <!-- <p>CT</p> -->
        </a>
        <a class="simple-text logo-normal row">
              <?=$this->session->fname;?>
              <!-- <a type="button" href="<?=base_url()?>Login_Controller/logout"><i class="nc-icon nc-button-power"></i></a> -->
              <!-- <button class="btn btn-primary btn-fab btn-icon btn-round" type="button" href="<?=base_url()?>Login_Controller/logout"><i class="nc-icon nc-button-power"></i><button> -->
          </a>
      </div>
      <div class="sidebar-wrapper">
        <ul class="nav">
          <li>
            <a href="<?=base_url()?>Login_Controller/DisplayAccount">
              <i class="nc-icon nc-bank"></i>
              <p>Dashboard</p>
            </a>
          </li>
          <li >
            <a href="<?=base_url('Login_Controller/viewAdminProfile')?>">
              <i class="nc-icon nc-circle-10"></i>
              <p>User Profile</p>
            </a>
          </li>
          <li >
            <a href="<?=base_url()?>allrecord">
              <i class="nc-icon nc-bullet-list-67"></i>
              <p>Vaccination</p>
            </a>
          </li>
          <li class="active" >
            <a href="<?=base_url()?>Login_Controller/UserManagement">
              <i class="nc-icon nc-tile-56"></i>
              <p>User Management</p>
            </a>
          </li>
        </ul>
      </div>
      </div>
      <div class="main-panel">
      <!-- Navbar -->
        <nav class="navbar navbar-expand-lg navbar-absolute fixed-top navbar-transparent">
          <div class="container-fluid">
            <div class="navbar-wrapper">
              <div class="navbar-toggle">
                <button type="button" class="navbar-toggler">
                  <span class="navbar-toggler-bar bar1"></span>
                  <span class="navbar-toggler-bar bar2"></span>
                  <span class="navbar-toggler-bar bar3"></span>
                </button>
              </div>
              <div>
                <a class="navbar-brand" href="javascript:;">Noveleta Cavite</a>
                <a href="<?= base_url('Login_Controller/logout');?>">
                  <button type="submit" class="btn btn-primary btn-round" style="position: absolute; right: 10px">Logout</button>
                </a>
              </div>
            </div>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navigation" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-bar navbar-kebab"></span>
              <span class="navbar-toggler-bar navbar-kebab"></span>
              <span class="navbar-toggler-bar navbar-kebab"></span>
            </button>
          </div>
        </nav>
      <!-- End Navbar -->
      <div class="content">
        <div class="row">
        <!-- Registration Approval -->
          <div class="col-md-12">
            <?php
              if($this->session->has_userdata('resident_deleted')){
                echo '<div class="alert alert-success" role="alert">
                Resident account was successfully deleted
                </div>';
              }
              if($this->session->has_userdata('admin_deleted')){
                echo '<div class="alert alert-success" role="alert">
                Admin account was successfully deleted
                </div>';
              }
            ?>
            <div class="card">
              <div class="card-header">
                <div class="row mb-3 ml-1"><h4 class="card-title mr-2">Resident Accounts</h4></div>
                <!--  -->
                <!-- PILL -->
                <ul class="nav nav-pills nav-pills-primary nav-pills-icons" role="tablist">
                    
                    <li class="nav-item">
                        <a class="nav-link active" href="#allacc" role="tab" data-toggle="tab">
                            <i class="nc-icon nc-circle-10"></i>
                            All
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link " href="#pendingacc" role="tab" data-toggle="tab">
                            <i class="nc-icon nc-settings"></i>
                            Pending
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#approvedacc" role="tab" data-toggle="tab">
                            <i class="nc-icon nc-single-copy-04"></i>
                            Approved
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#deniedacc" role="tab" data-toggle="tab">
                            <i class="nc-icon nc-single-copy-04"></i>
                            Denied
                        </a>
                    </li>
                </ul>

            
                <div class="tab-content tab-space">
                
                  <!-- NAV PILL 1 -->
                  <div class="tab-pane active" id="allacc">
                    <div class="">
                      <table class="table">
                        <thead class=" text-primary">
                          <th>Resident ID</th>
                          <th>Full Name</th>
                          <th>Username</th>
                          <th>Address</th>
                          <th>Approval Status</th>
                          <th></th>
                        </thead>
                        <tbody>
                        <?php foreach($alluser as $user):?>
                          <tr>
                            <td><?=$user->account_id?></td>
                            <td><?=$user->account_fname.' '.$user->account_lname?></td>
                            <td><?=$user->account_uname?></td>
                            <td><?=$user->account_housenum.' '.$user->account_street?></td>
                            <td>
                              <?php
                                if($user->account_approvalStat=='1'){
                                  echo 'Approved';
                                }
                                elseif($user->account_approvalStat=='2'){
                                  echo 'Denied';
                                }
                                else{
                                  echo 'Pending';
                                }
                              ?>
                            </td>
                            <td>
                              <a href="<?=$this->config->base_url()?>login_controller/viewResident/<?=$user->account_id;?>" class="btn btn-info btn-round crudButtons"><i class="nc-icon nc-zoom-split"></i></a>
                              <a href="<?=$this->config->base_url()?>login_controller/editResident/<?=$user->account_id;?>" class="btn btn-info btn-round"><i class="nc-icon nc-ruler-pencil"></i></a>
                              <a><button class="btn btn-info btn-round delResident" type="submit" onclick="deleteResident()" id="<?=$user->account_id;?>" value="<?=$user->account_id;?>"><i class="nc-icon nc-simple-delete"></i></a>
                            </td>
                          </tr>
                        <?php endforeach;?>  
                        </tbody>
                      </table>
                    </div>
                  </div>
                  <!-- END NAV PILL 1 -->

                  <!-- NAV PILL 2 -->
                  <div class="tab-pane" id="pendingacc">
                    <div class="">
                      <table class="table">
                        <thead class=" text-primary">
                          <th>Resident ID</th>
                          <th>Full Name</th>
                          <th>Username</th>
                          <th>Address</th>
                          <th>Approval Status</th>
                          <th></th>
                        </thead>
                        <tbody>
                        
                        <?php 
                        $count=0;
                        foreach($alluser as $user):?>
                          <?php if($user->account_approvalStat=='3'){?>
                          <tr>
                            <td><?=$user->account_id?></td>
                            <td><?=$user->account_fname.' '.$user->account_lname?></td>
                            <td><?=$user->account_uname?></td>
                            <td><?=$user->account_housenum.' '.$user->account_street?></td>
                            <td>
                              <?php
                                  echo 'Pending';
                              ?>
                            </td>
                            <td>
                              <a href="<?=$this->config->base_url()?>login_controller/viewResident/<?=$user->account_id;?>" class="btn btn-info btn-round crudButtons"><i class="nc-icon nc-zoom-split"></i></a>
                              <a><button class="btn btn-info btn-round appResident crudButtons" type="submit" onclick="approveResident()" id="<?=$user->account_id;?>" value="<?=$user->account_id;?>"><i class="nc-icon nc-check-2"></i></a>
                              <a><button class="btn btn-info btn-round delResident" type="submit" onclick="deleteResident()" id="<?=$user->account_id;?>" value="<?=$user->account_id;?>"><i class="nc-icon nc-simple-delete"></i></a>
                            </td>
                          </tr>
                          <?php };
                          if($user->account_approvalStat=='3'){
                            $count++;
                          }
                          ?>
                        <?php endforeach;?>
                        </tbody>
                      </table>
                      <div class="mb-4">
                      <div class="mb-4 text-center">
                        <?php
                        if($count==0){
                            echo 'There are no records found';
                          }
                        ?> 
                      </div>
                      </div>
                    </div>
                  </div>
                  <!-- END NAV PILL 2 -->

                  <!-- NAV PILL 3 -->
                  <div class="tab-pane" id="approvedacc">
                    <div class="">
                      <table class="table">
                        <thead class=" text-primary">
                          <th>Resident ID</th>
                          <th>Full Name</th>
                          <th>Username</th>
                          <th>Address</th>
                          <th>Approval Status</th>
                          <th></th>
                        </thead>
                        <tbody>
                        <?php 
                        $count=0;
                        foreach($alluser as $user):?>
                          <?php if($user->account_approvalStat=='1'){?>
                          <tr>
                            <td><?=$user->account_id?></td>
                            <td><?=$user->account_fname.' '.$user->account_lname?></td>
                            <td><?=$user->account_uname?></td>
                            <td><?=$user->account_housenum.' '.$user->account_street?></td>
                            <td>
                              <?php
                                  echo 'Approved';
                              ?>
                            </td>
                            <td>
                            <a href="<?=$this->config->base_url()?>login_controller/viewResident/<?=$user->account_id;?>" class="btn btn-info btn-round crudButtons"><i class="nc-icon nc-zoom-split"></i></a>
                              <a href="<?=$this->config->base_url()?>login_controller/editResident/<?=$user->account_id;?>" class="btn btn-info btn-round"><i class="nc-icon nc-ruler-pencil"></i></a>
                              <a><button class="btn btn-info btn-round delResident" type="submit" onclick="deleteResident()" id="<?=$user->account_id;?>" value="<?=$user->account_id;?>"><i class="nc-icon nc-simple-delete"></i></a>
                            </td>
                          </tr>
                          <?php };
                          if($user->account_approvalStat=='1'){
                            $count++;
                          }
                          ?>
                        <?php endforeach;?>
                        </tbody>
                      </table>
                      <div class="mb-4 text-center">
                        <?php
                        if($count==0){
                            echo 'There are no records found';
                          }
                        ?> 
                      </div>
                    </div>
                  </div>
                  <!-- END NAV PILL 3 -->

                  <!-- NAV PILL 4 -->
                  <div class="tab-pane" id="deniedacc">
                    <div class="">
                      <table class="table">
                        <thead class=" text-primary">
                          <th>Resident ID</th>
                          <th>Full Name</th>
                          <th>Username</th>
                          <th>Address</th>
                          <th>Approval Status</th>
                          <th></th>
                        </thead>
                        <tbody>
                        <?php 
                        $count=0;
                        foreach($alluser as $user):?>
                          <?php if($user->account_approvalStat=='2'){?>
                          <tr>
                            <td><?=$user->account_id?></td>
                            <td><?=$user->account_fname.' '.$user->account_lname?></td>
                            <td><?=$user->account_uname?></td>
                            <td><?=$user->account_housenum.' '.$user->account_street?></td>
                            <td>
                              <?php
                                  echo 'Denied';
                              ?>
                            </td>
                            <td>
                            <a href="<?=$this->config->base_url()?>login_controller/viewResident/<?=$user->account_id;?>" class="btn btn-info btn-round crudButtons"><i class="nc-icon nc-zoom-split"></i></a>
                              <a href="<?=$this->config->base_url()?>login_controller/editResident/<?=$user->account_id;?>" class="btn btn-info btn-round"><i class="nc-icon nc-ruler-pencil"></i></a>
                              <a><button class="btn btn-info btn-round delResident" type="submit" onclick="deleteResident()" id="<?=$user->account_id;?>" value="<?=$user->account_id;?>"><i class="nc-icon nc-simple-delete"></i></a>
                            </td>
                          </tr>
                          <?php };
                          if($user->account_approvalStat=='2'){
                            $count=$count+1;
                          }
                          ?>
                        <?php endforeach;?>
                        </tbody>
                      </table>
                      <div class="mb-4 text-center">
                        <?php
                        if($count==0){
                            echo 'There are no records found';
                          }
                        ?> 
                      </div>
                    </div>
                  </div>
                  <!-- END NAV PILL 4 -->
                </div>
              </div>
              </div>
            </div>


            <!-- Admin -->
            <div class="col-md-12">
            <div class="card">
              <div class="card-header">
                <div class="row mb-3 ml-1"><h4 class="card-title mr-2">Admin Accounts</h4><button class="btn btn-primary btn-fab btn-icon btn-round"  data-toggle="modal" data-target="#add-new-admin"><i class="nc-icon nc-simple-add"></i></button></div>
              <div class="tab-pane" id="allAdmin">
                <div class="">
                  <table class="table">
                  <thead class=" text-primary">
                      <th>Admin ID</th>
                      <th>Full Name</th>
                      <th>Username</th>
                      <th>Contact Number</th>
                      <!-- <th>Email</th> -->
                      <th>Account Status</th>
                      <th></th>
                    </thead>
                    <tbody>
                    <?php 
                     $count=0;
                      foreach($alladmin as $admin):?>
                      
                      <tr>
                        <td><?=$admin->admin_id?></td>
                        <td><?=$admin->admin_fname.' '.$admin->admin_lname?></td>
                        <td><?=$admin->admin_uname?></td>
                        <td><?=$admin->admin_contactnum?></td>
                        <!-- <td><?=$admin->admin_email?></td> -->
                        <td>
                          <?php
                            if($admin->admin_accStatus=='1'){
                              echo 'Active';
                            }
                            else{
                              echo 'Deactivated';
                            }
                          ?>
                        </td>
                        <td>
                        <!-- <a><button name="edituser-btn"  class="btn btn-success btn-sm btn-update-user btn-up" type="submit" onclick="edituserFunction()"  id="'.$row['account_id'].'" value="'.$row['account_id'].'"><i class="fas fa-pen"></i></a></button> -->
                          <a href="<?=$this->config->base_url()?>login_controller/viewAdmin/<?=$admin->admin_id;?>" class="btn btn-info btn-round"><i class="nc-icon nc-zoom-split"></i></a>
                          <a href="<?=$this->config->base_url()?>login_controller/edit/<?=$admin->admin_id;?>" class="btn btn-info btn-round"><i class="nc-icon nc-ruler-pencil"></i></a>
                          <a><button class="btn btn-info btn-round delAdmin" type="submit" onclick="deleteAdmin()" id="<?=$admin->admin_id;?>" value="<?=$admin->admin_id;?>"><i class="nc-icon nc-simple-delete"></i></a>
                        </td>
                      </tr>
                    <?php  endforeach;?>
                    </tbody>
                  </table>
                </div>
              </div>
    </div>
  </div>

  <script>

  function deluserFunction() {
		deluser_btn=document.querySelectorAll('.delUser')
        deluser_btn.forEach(onebyone => {
            onebyone.addEventListener('click',delete_user)
        })
        function delete_user(){
        var uid_del = this.id;
        var status=confirm("Are you sure to delete this account?");
        if (status==true){ 
          window.location.href="<?=base_url()?>/Login_Controller/deleteUser"+uid_del;
        }
        else{
            alert("Delete user account cancelled");
            window.location.href="<?=base_url()?>/Login_Controller/UserManagement";
        }
	    }
	}

	function previewFunction() {
		crudBtn=document.querySelectorAll('.crudButtons')
        crudBtn.forEach(onebyone => {
            onebyone.addEventListener('click',view_userAccount)
        })
        function view_userAccount(){
			var id_user= this.id;
			// var id=itm_id_edit ;
			// console.log(itm_id_edit);
			window.location.href="<?=base_url()?>/"+id_prev;
		}
	}
</script>

  <div class="modal fade" id="Mymodal">
	    <div class="modal-dialog modal-dialog-centered">
	      <div class="modal-content">
	        <div class="modal-body">
          <div><a href="javascript:void(0)" class="exit" onclick="closePreview()">&times;</a></div>
              <!-- <?=$oid;?> -->
          </div>
        </div>
      </div>
  </div>

  <!-- <?php
    if (isset($_GET['prdid'])) {
      echo '<script>$("#userDetails").modal("show");</script>';
    }
  ?> -->
  <!--   Core JS Files   -->
  <script src="<?=base_url()?>assets/js/core/jquery.min.js"></script>
  <script src="<?=base_url()?>assets/js/core/popper.min.js"></script>
  <script src="<?=base_url()?>assets/js/core/bootstrap.min.js"></script>
  <script src="<?=base_url()?>assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
  <!--  Google Maps Plugin    -->
  <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
  <!-- Chart JS -->
  <script src="<?=base_url()?>assets/js/plugins/chartjs.min.js"></script>
  <!--  Notifications Plugin    -->
  <script src="<?=base_url()?>assets/js/plugins/bootstrap-notify.js"></script>
  <!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="<?=base_url()?>assets/js/paper-dashboard.min.js?v=2.0.1" type="text/javascript"></script><!-- Paper Dashboard DEMO methods, don't include it in your project! -->
  <script src="<?=base_url()?>assets/demo/demo.js"></script>
  <script type="text/javascript">	

    $(document).ready(function(){
      $("#error-alert").hide();
   

    function closePreview() {
      $("#userDetails").modal("hide");
    }


    $("#sendForm").click(function () {
        $.post('<?= site_url('Login_Controller/createAdminAccount') ?>', $('#form1').serialize(), function (data) {
            if (data.code === 1)
            {
              $("#error-alert").show();
                $("#error-alert").removeClass('alert-success').addClass('alert-danger').removeClass('hidden').html(data.msg);
            } else {
                $("#error-alert").removeClass('alert-danger').addClass('alert-success').removeClass('hidden').html(data.msg);
                // window.location.href="http://localhost/CodeIgniter/Login_Controller/createAdminAccount";
            }
        }, 'json');
    });

  });
</script>
</body>

</html>