<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>
    
  </title>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
  <!--     Fonts and icons     -->
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
  <!-- CSS Files -->
  <link href="<?=base_url()?>assets/css/bootstrap.min.css" rel="stylesheet" />
  <link href="<?=base_url()?>assets/css/paper-dashboard.css?v=2.0.1" rel="stylesheet" />
  <!-- CSS Just for demo purpose, don't include it in your project -->
  <link href="<?=base_url()?>assets/demo/demo.css" rel="stylesheet" />
  <style>
		@import url('https://fonts.googleapis.com/css?family=Poppins');

/*basic reset*/
* {margin: 0; padding: 0;}

html {
  background: linear-gradient(0deg, rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), 
    url(https://cloudfront-us-east-2.images.arcpublishing.com/reuters/NS32IE6UUBKUFDTNRBMSYMUPKA.jpg) 
    no-repeat center center fixed; 
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;
}

body {
  height: 100%;
  font-family: "Poppins", sans-serif;
  height: 100vh;
}

		/*form styles*/
		#msform {
			width: 450px;
			margin: 50px auto;
			text-align: center;
			position: relative;
		}
		
		#msform fieldset {
			background: white;
			border: 0 none;
			border-radius: 10px 10px 10px 10px;
			box-shadow: 0 0 15px 1px rgba(0, 0, 0, 0.4);
			padding: 30px;
			box-sizing: border-box;
			width: 500px;
			/*stacking fieldsets above each other*/
			margin-left: -20px;
			position: relative;
		}
		
		/*Hide all except first fieldset*/
		#msform fieldset:not(:first-of-type) {
			display: none;
		}
		
		/*inputs*/
		#msform input, #msform textarea {
			padding: 10px;
			border: 1px solid #ccc;
			border-radius: 3px;
			margin-bottom: 10px;
			width: 100%;
			box-sizing: border-box;
			font-family: "Poppins", sans-serif;
			color: black;
			font-size: 13px;
			border: 2px solid #ececec;
		}
		
		input[type=text]:focus {
			background-color: #fff;
			border-bottom: 2px solid #5fbae9;
		}
		
		input[type=text]:placeholder {
			color: #cccccc;
		}
		
		input[type=file] {
			border: none !important;
			padding: 0px !important;
		}
		
		input[type=button], input[type=submit], input[type=reset]  {
			width: 30% !important;
			background-color: #56baed;
			border: none !important;
			color: white !important;
			padding: 15px 80px;
			text-align: center;
			text-decoration: none;
			display: inline-block;
			text-transform: uppercase;
			font-size: 13px;
			-webkit-box-shadow: 0 10px 30px 0 rgba(95,186,233,0.4);
			box-shadow: 0 10px 30px 0 rgba(95,186,233,0.4);
			-webkit-border-radius: 5px 5px 5px 5px;
			border-radius: 5px 5px 5px 5px;
			-webkit-transition: all 0.3s ease-in-out;
			-moz-transition: all 0.3s ease-in-out;
			-ms-transition: all 0.3s ease-in-out;
			-o-transition: all 0.3s ease-in-out;
			transition: all 0.3s ease-in-out;
		}
		
		input[type=button]:hover, input[type=submit]:hover, input[type=reset]:hover  {
			background-color: #39ace7;
		}
		
		input[type=button]:active, input[type=submit]:active, input[type=reset]:active  {
			-moz-transform: scale(0.95);
			-webkit-transform: scale(0.95);
			-o-transform: scale(0.95);
			-ms-transform: scale(0.95);
			transform: scale(0.95);
		}	

    .checkboxes {
			display: flex;
			justify-content: center;
			align-items: top;
			vertical-align: center;
			word-wrap: break-word;
			margin-left: -13px;
			margin-top: 5px;
		}


    .close {
      color: dodgerblue;
      float: right;
      font-size: 1rem;
      font-weight: bold;
      background-color: #51cbce;
      border: none;
      padding: 12px 20px;
    }
    #admin-card{
      box-shadow:none;
    }
</style>

</head>

<body class="">
  <div class="wrapper ">
    <div class="sidebar" data-color="white" data-active-color="danger">
      <div class="logo">
        <a class="simple-text logo-mini" href="<?=base_url()?>Login_Controller/viewAdminProfile">
          <div class="logo-image-small">
            <img src="<?=base_url()?>assets/img/logo-small.png">
          </div>
          <!-- <p>CT</p> -->
        </a>
        <a class="simple-text logo-normal row">
              <?=$this->session->fname;?>
              <!-- <a type="button" href="<?=base_url()?>Login_Controller/logout"><i class="nc-icon nc-button-power"></i></a> -->
              <!-- <button class="btn btn-primary btn-fab btn-icon btn-round" type="button" href="<?=base_url()?>Login_Controller/logout"><i class="nc-icon nc-button-power"></i><button> -->
          </a>
      </div>
      <div class="sidebar-wrapper">
        <ul class="nav">
          <li >
            <a href="<?=base_url()?>Login_Controller/DisplayAccount">
              <i class="nc-icon nc-bank"></i>
              <p>Dashboard</p>
            </a>
          </li>
          <li >
            <a href="<?=base_url('Login_Controller/viewAdminProfile')?>">
              <i class="nc-icon nc-circle-10"></i>
              <p>User Profile</p>
            </a>
          </li>
          <li class="active ">
            <a href="<?=base_url()?>allrecord">
              <i class="nc-icon nc-bullet-list-67"></i>
              <p>Vaccination</p>
            </a>
          </li>
          <li >
            <a href="<?=base_url()?>Login_Controller/UserManagement">
              <i class="nc-icon nc-tile-56"></i>
              <p>User Management</p>
            </a>
          </li>
        </ul>
      </div>
      </div>
      <div class="main-panel">
      <!-- Navbar -->
        <nav class="navbar navbar-expand-lg navbar-absolute fixed-top navbar-transparent">
          <div class="container-fluid">
            <div class="navbar-wrapper">
              <div class="navbar-toggle">
                <button type="button" class="navbar-toggler">
                  <span class="navbar-toggler-bar bar1"></span>
                  <span class="navbar-toggler-bar bar2"></span>
                  <span class="navbar-toggler-bar bar3"></span>
                </button>
              </div>
              <div>
                <a class="navbar-brand" href="javascript:;">Noveleta Cavite</a>
                <a href="<?= base_url('Login_Controller/logout');?>">
                  <button type="submit" class="btn btn-primary btn-round" style="position: absolute; right: 10px">Logout</button>
                </a>
              </div>
            </div>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navigation" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-bar navbar-kebab"></span>
              <span class="navbar-toggler-bar navbar-kebab"></span>
              <span class="navbar-toggler-bar navbar-kebab"></span>
            </button>
          </div>
        </nav>
      <!-- End Navbar -->
      <div class="content">
        <div class="row">
        <!-- Registration Approval -->
          <div class="col-md-12">
            <?php
              if($this->session->has_userdata('resident_deleted')){
                echo '<div class="alert alert-success" role="alert">
                Resident account was successfully deleted
                </div>';
              }
              if($this->session->has_userdata('admin_deleted')){
                echo '<div class="alert alert-success" role="alert">
                Admin account was successfully deleted
                </div>';
              }
            ?>
            <div class="card">
              <div class="card-header">
                <div class="row mb-3 ml-1"><h4 class="card-title mr-2">Vaccination</h4></div>
                <!--  -->

            
                <div class="tab-content tab-space">
                
                  <!-- NAV PILL 1 -->
                  <div class="tab-pane active" id="allacc">
                    <div class="">
                      <table class="table">
                        <thead class=" text-primary">
                        <th></th>
                        <th>Number</th>
                        <th>Name</th>
                        <th>Category</th>
                        <th>Account Status</th>
                        <th>Birthday</th>
                        </thead>
                        <tbody>
                        <?php foreach($records as $record){ ?>
        <tr>
        <td> <a href="<?=base_url()?>viewrecord?acctId=<?=$record->account_id?>" class="btn btn-info btn-round crudButtons"><i class="nc-icon nc-single-02"></i></a></td>
        <td><?=$record->account_id?></td>
        <?php
        echo '<td>'.$record->account_fname.' '.$record->account_mname.' '.$record->account_lname.'</td>';
       
        if ($record->account_prioritycateg == 1){
            echo '<td>A1 - Medical Frontliner</td>';
        }
        elseif ($record->account_prioritycateg == 2){
            echo '<td>A2 - Senior Citizen</td>';
        }
        elseif ($record->account_prioritycateg == 3){
            echo '<td>A3 - Person with Comorbidity</td>';
        }
        elseif ($record->account_prioritycateg == 4){
            echo '<td>A4 - Economic Frontliners</td>';
        }
        elseif ($record->account_prioritycateg == 4){
            echo '<td>A5 - Indigent Citizen</td>';
        }
        else{
            echo '<td>Other</td>';
        }

        

        if ($record->account_approvalStat == 1){
            echo '<td>Approved</td>';
        }
        elseif ($record->account_prioritycateg == 2){
            echo '<td>Denied</td>';
        }
        else{
            echo '<td>Pending</td>';
        }
        echo '<td>'.$record->account_bdate.'</td> 
        </tr>';
        }
        ?>
        </tr>

                        </tbody>
                      </table>
                    </div>
                  </div>
                  <!-- END NAV PILL 1 -->

            </div>


            <!-- Admin -->
            
    </div>
  </div>

  <script>

  function deluserFunction() {
		deluser_btn=document.querySelectorAll('.delUser')
        deluser_btn.forEach(onebyone => {
            onebyone.addEventListener('click',delete_user)
        })
        function delete_user(){
        var uid_del = this.id;
        var status=confirm("Are you sure to delete this account?");
        if (status==true){ 
          window.location.href="<?=base_url()?>/Login_Controller/deleteUser"+uid_del;
        }
        else{
            alert("Delete user account cancelled");
            window.location.href="<?=base_url()?>/Login_Controller/UserManagement";
        }
	    }
	}

	function previewFunction() {
		crudBtn=document.querySelectorAll('.crudButtons')
        crudBtn.forEach(onebyone => {
            onebyone.addEventListener('click',view_userAccount)
        })
        function view_userAccount(){
			var id_user= this.id;
			// var id=itm_id_edit ;
			// console.log(itm_id_edit);
			window.location.href="<?=base_url()?>/"+id_prev;
		}
	}
</script>

  <div class="modal fade" id="Mymodal">
	    <div class="modal-dialog modal-dialog-centered">
	      <div class="modal-content">
	        <div class="modal-body">
          <div><a href="javascript:void(0)" class="exit" onclick="closePreview()">&times;</a></div>
              <!-- <?=$oid;?> -->
          </div>
        </div>
      </div>
  </div>

  <!-- <?php
    if (isset($_GET['prdid'])) {
      echo '<script>$("#userDetails").modal("show");</script>';
    }
  ?> -->
  <!--   Core JS Files   -->
  <script src="<?=base_url()?>assets/js/core/jquery.min.js"></script>
  <script src="<?=base_url()?>assets/js/core/popper.min.js"></script>
  <script src="<?=base_url()?>assets/js/core/bootstrap.min.js"></script>
  <script src="<?=base_url()?>assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
  <!--  Google Maps Plugin    -->
  <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
  <!-- Chart JS -->
  <script src="<?=base_url()?>assets/js/plugins/chartjs.min.js"></script>
  <!--  Notifications Plugin    -->
  <script src="<?=base_url()?>assets/js/plugins/bootstrap-notify.js"></script>
  <!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="<?=base_url()?>assets/js/paper-dashboard.min.js?v=2.0.1" type="text/javascript"></script><!-- Paper Dashboard DEMO methods, don't include it in your project! -->
  <script src="<?=base_url()?>assets/demo/demo.js"></script>
  <script type="text/javascript">	

    $(document).ready(function(){
      $("#error-alert").hide();
   

    function closePreview() {
      $("#userDetails").modal("hide");
    }


    $("#sendForm").click(function () {
        $.post('<?= site_url('Login_Controller/createAdminAccount') ?>', $('#form1').serialize(), function (data) {
            if (data.code === 1)
            {
              $("#error-alert").show();
                $("#error-alert").removeClass('alert-success').addClass('alert-danger').removeClass('hidden').html(data.msg);
            } else {
                $("#error-alert").removeClass('alert-danger').addClass('alert-success').removeClass('hidden').html(data.msg);
                // window.location.href="http://localhost/CodeIgniter/Login_Controller/createAdminAccount";
            }
        }, 'json');
    });

  });
</script>
</body>