<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>
    Edit Profile
  </title>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
  <!--     Fonts and icons     -->
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
  <!-- CSS Files -->
  <link href="<?=base_url()?>assets/css/bootstrap.min.css" rel="stylesheet" />
  <link href="<?=base_url()?>assets/css/paper-dashboard.css?v=2.0.1" rel="stylesheet" />
  <!-- CSS Just for demo purpose, don't include it in your project -->
  <link href="<?=base_url()?>assets/demo/demo.css" rel="stylesheet" />

  <style>
    .dropdownBox{
      width: 100%;
      /* height:rem; */
      border: 1px solid #ccc; 
      border-radius: 3px; 
      /* box-sizing: border-box;  */
      font-size: 13px; 
      padding: 10px; 
      font-family: 'Poppins', sans-serif; 
      margin-bottom: 10px; 
      border: 2px solid #ececec;
    }
  </style>
</head>



<body class="">

  <div class="wrapper ">
    <div class="sidebar" data-color="white" data-active-color="danger">
      <div class="logo">
        <a class="simple-text logo-mini" href="<?=base_url()?>Login_Controller/viewAdminProfile">
          <div class="logo-image-small">
            <img src="<?=base_url()?>assets/img/logo-small.png">
          </div>
          <!-- <p>CT</p> -->
        </a>
        <a class="simple-text logo-normal">
        <?=$this->session->fname;?>
          <!-- <div class="logo-image-big">
            <img src="../assets/img/logo-big.png">
          </div> -->
        </a>
      </div>
      <div class="sidebar-wrapper">
        <ul class="nav">
          <li >
            <a href="<?=base_url()?>Login_Controller/DisplayAccount">
              <i class="nc-icon nc-bank"></i>
              <p>Dashboard</p>
            </a>
          </li>
          <li >
            <a href="<?=base_url('Login_Controller/viewAdminProfile')?>">
              <i class="nc-icon nc-circle-10"></i>
              <p>User Profile</p>
            </a>
          </li>
          <li >
            <a href="<?=base_url()?>allrecord">
              <i class="nc-icon nc-bullet-list-67"></i>
              <p>Vaccination</p>
            </a>
          </li>
          <li class="active ">
            <a href="<?=base_url()?>Login_Controller/UserManagement">
              <i class="nc-icon nc-tile-56"></i>
              <p>User Management</p>
            </a>
          </li>
        </ul>
      </div>
      </div>
      <div class="main-panel">
      <!-- Navbar -->
        <nav class="navbar navbar-expand-lg navbar-absolute fixed-top navbar-transparent">
          <div class="container-fluid">
            <div class="navbar-wrapper">
              <div class="navbar-toggle">
                <button type="button" class="navbar-toggler">
                  <span class="navbar-toggler-bar bar1"></span>
                  <span class="navbar-toggler-bar bar2"></span>
                  <span class="navbar-toggler-bar bar3"></span>
                </button>
              </div>
              <div>
                <a class="navbar-brand" href="javascript:;">Noveleta Cavite</a>
                <a href="<?= base_url('Login_Controller/logout');?>">
                  <button type="submit" class="btn btn-primary btn-round" style="position: absolute; right: 10px">Logout</button>
                </a>
              </div>
            </div>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navigation" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-bar navbar-kebab"></span>
              <span class="navbar-toggler-bar navbar-kebab"></span>
              <span class="navbar-toggler-bar navbar-kebab"></span>
            </button>
          </div>
        </nav>
      <!-- End Navbar -->
      <?php
                foreach($userId as $detail){
                    
              ?>
      <div class="content">
        <div class="row">
          <div class="col-md-4">
            <div class="card card-user">
              <div class="image">
                <img src="<?=base_url()?>assets/img/damir-bosnjak.jpg" alt="...">
              </div>
                <div class="author">
                  <a href="#" style="text-decoration:none">
                    <img class="avatar border-gray" src="<?=base_url()?>upload/<?=$detail->account_image?>" alt="...">
                    <h5 class="title"><?=$detail->account_uname?></h5>
                  </a>
                </div>
                <p class="text-center">Priority Category: 
                  <?php
                    if($detail->account_prioritycateg=='Others'){
                      echo $detail->account_prioritycateg;    
                    }
                    else{
                      echo 'A'.$detail->account_prioritycateg;
                    }
                  ?>
                </p>
            </div>
           
          </div>
          <div class="col-md-8">
            <div class="card card-user">
              <div class="card-header">
                <h5 class="card-title">Personal Information</h5>
              </div>

              <div class="card-body">
                  <form  action="<?=base_url()?>Login_Controller/confirmEditResident" method="post" enctype="multipart/form-data">
                  <div class="row">
                    <div class="col-md-5 pr-1">
                      <div class="form-group">
                        <label>First Name</label>
                        <input type="text" class="form-control"  name="fname" placeholder="<?=$detail->account_fname;?>" value="<?=$detail->account_fname;?>">
                      </div>
                    </div>
                    <div class="col-md-3 px-1">
                      <div class="form-group">
                        <label>Middle Name</label>
                        <input type="text" class="form-control" name="mname" placeholder="<?=$detail->account_mname;?>" value="<?=$detail->account_mname;?>">
                      </div>
                    </div>
                    <div class="col-md-4 pl-1">
                      <div class="form-group">
                        <label for="exampleInputEmail1">Last Name</label>
                        <input type="text" class="form-control" name="lname" placeholder="<?=$detail->account_lname;?>" value="<?=$detail->account_lname;?>">
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-6 pr-1">
                      <div class="form-group">
                        <label>Birthdate</label>
                        <input type="date" class="form-control"  placeholder="<?=$detail->account_bdate?>"  name="birthdate" value="<?=$detail->account_bdate?>"/>
                      </div>
                    </div>
                    <div class="col-md-6 pl-1">
                      <div class="form-group">
                        <label>Gender</label>
                        <input list="gender"  class="form-control" name="gender" required>
                          <datalist id="gender" name="gender" id="genderSelect" >
                            <option value="Male" selected>Male</option>
                            <option value="Female">Female</option>
                          </datalist>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-12">
                      <div class="form-group">
                        <label>House Number</label>
                        <input type="text" class="form-control" placeholder="<?=$detail->account_housenum?>"  name="housenum" value="<?=$detail->account_housenum?>" >
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-6 pr-1">
                      <div class="form-group">
                        <label>Street</label>
                        <input type="text" class="form-control" placeholder="<?=$detail->account_street?>" name="street" value="<?=$detail->account_street?>">
                      </div>
                    </div>
                    <div class="col-md-6 pl-1">
                      <div class="form-group">
                        <label>Subdivision</label>
                        <input type="text" class="form-control" placeholder="<?=$detail->account_subdivision?>" name="subdivision" value="<?=$detail->account_subdivision?>">
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-6 pr-1">
                      <div class="form-group">
                        <label>Email</label>
                        <input type="email" class="form-control"  placeholder="<?=$detail->account_email?>" name="email" value="<?=$detail->account_email?>">
                      </div>
                    </div>
                    <div class="col-md-6 pl-1">
                      <div class="form-group">
                        <label>Contact Number</label>
                        <input type="text" class="form-control"  placeholder="<?=$detail->account_contactnum?>" name="contact" value="<?=$detail->account_contactnum?>">
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-6 pr-1">
                      <div class="form-group">
                        <label>Account Status</label>
                          <input list="accstatus"  class="form-control" name="accstatus" value="<?= set_value("accstatus");?>" required>
                          <datalist id="accstatus" name="accstatus" id="accstatusSelect">
                          <?php foreach($accountstat as $accstat):?>
                              <option value-hidden="<?=$accstat->accstatus_id?>" selected>
                                <?=$accstat->accstatus_name?>
                              </option>
                          <?php endforeach;?>  
                          </datalist>
                      </div>
                    </div>
                    <div class="col-md-6 pl-1">
                      <div class="form-group">
                        <label>Approval Status</label>
                          <input list="appstatus"  class="form-control" name="appstatus" value="<?= set_value("appstatus");?>" required>
                          <datalist id="appstatus" name="appstatus" id="appstatusSelect" value="">
                          <?php foreach($approvalstat as $appstat):?>
                              <option value-hidden="<?=$appstat->approvalstat_id?>" selected>
                                <?=$appstat->approvalstat_name?>
                              </option>
                          <?php endforeach;?>  
                          </datalist>
                      </div>
                    </div>
                  </div>
                  
                  <br>
                  <h5 class="card-title">Health Information</h5>
                  <br>
                  <div class="row">
                    
                    <div class="col-md-5 ml-2 form-group">
                        <a href="#"><b><h6 class="">Type of Commorbidity</b></h6></a>
                        <div class="">
                            <label><b>Allergies: </b><?=$detail->account_allergy?></label><br>
                            <label><b>Diseases: </b><?=$detail->account_disease?><br></label><br>
                            <label><b>Diabetic: </b><?=$detail->account_diabetic?><br></label><br>
                            <label><b>Hypertension: </b><?=$detail->account_hypertension?><br></label><br>
                            <label><b>Organ Transplant: </b><?=$detail->account_transplant?><br></label><br>
                        </div>
                    </div>
                    <div class="col-md-6 form-group">
                        <a href="#"><b><h6 class="">Type of Commorbidity</b></h6></a>
                        <div>
                            <label><b>Fever: </b><?=$detail->account_fever?></label><br>
                            <label><b>Cough: </b><?=$detail->account_cough?><br></label><br>
                            <label><b>Body Pain: </b><?=$detail->account_bodypain?><br></label><br>
                            <label><b>Shortness of Breath: </b><?=$detail->account_breath?><br></label><br>
                            <label><b>Lost of Taste/Smell: </b><?=$detail->account_smell?><br></label><br>
                            <label><b>Diarrhea: </b><?=$detail->account_diarrhea?><br></label><br>
                        </div>
                    </div>
                  </div>

                    <?php
                        }

                        foreach($userId as $info){
                            $id=$info->account_id;
                        }
                    ?>
                    
                    <input type="hidden" id="<?=$id?>" value="<?=$id?>" name="uid">
                  <div class="row">
                    <div class="update ml-auto mr-auto">
                        <a href="<?=base_url()?>Login_Controller/UserManagement"><button type="button" class="btn btn-primary btn-round">Cancel</button></a>
                        <button type="submit" value="Submit" class="btn btn-primary btn-round">Update</button>
                    </div>
                  </div>
                </form>   
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    </div>
  </div>

  <!--   Core JS Files   -->
  <script src="<?=base_url()?>assets/js/core/jquery.min.js"></script>
  <script src="<?=base_url()?>assets/js/core/popper.min.js"></script>
  <script src="<?=base_url()?>assets/js/core/bootstrap.min.js"></script>
  <script src="<?=base_url()?>assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
  <!--  Google Maps Plugin    -->
  <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
  <!-- Chart JS -->
  <script src="<?=base_url()?>assets/js/plugins/chartjs.min.js"></script>
  <!--  Notifications Plugin    -->
  <script src="<?=base_url()?>assets/js/plugins/bootstrap-notify.js"></script>
  <!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="<?=base_url()?>assets/js/paper-dashboard.min.js?v=2.0.1" type="text/javascript"></script><!-- Paper Dashboard DEMO methods, don't include it in your project! -->
  <script src="<?=base_url()?>assets/demo/demo.js"></script>

</body>

</html>