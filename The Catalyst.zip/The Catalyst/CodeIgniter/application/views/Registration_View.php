<!DOCTYPE html>
<html lang="en" >
<head>
	<meta charset="UTF-8">
	<title>Registration</title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">
	<link rel="stylesheet" href="./style.css">

	<style>
		/*custom font*/
		@import url('https://fonts.googleapis.com/css?family=Poppins');

		/*basic reset*/
		* {margin: 0; padding: 0;}

		html {
			background: linear-gradient(0deg, rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), 
				url(https://cloudfront-us-east-2.images.arcpublishing.com/reuters/NS32IE6UUBKUFDTNRBMSYMUPKA.jpg) 
				no-repeat center center fixed; 
			-webkit-background-size: cover;
			-moz-background-size: cover;
			-o-background-size: cover;
			background-size: cover;
		}

		body {
			height: 100%;
			font-family: "Poppins", sans-serif;
			height: 100vh;
		}
		
		/*form styles*/
		#msform {
			width: 450px;
			margin: 50px auto;
			text-align: center;
			position: relative;
		}
		
		#msform fieldset {
			background: white;
			border: 0 none;
			border-radius: 10px 10px 10px 10px;
			box-shadow: 0 0 15px 1px rgba(0, 0, 0, 0.4);
			padding: 30px;
			box-sizing: border-box;
			width: 500px;
			/*stacking fieldsets above each other*/
			margin-left: -20px;
			position: relative;
		}
		
		/*Hide all except first fieldset*/
		#msform fieldset:not(:first-of-type) {
			display: none;
		}
		
		/*inputs*/
		#msform input, #msform textarea {
			padding: 10px;
			border: 1px solid #ccc;
			border-radius: 3px;
			margin-bottom: 10px;
			width: 100%;
			box-sizing: border-box;
			font-family: "Poppins", sans-serif;
			color: black;
			font-size: 13px;
			border: 2px solid #ececec;
		}
		
		input[type=text]:focus {
			background-color: #fff;
			border-bottom: 2px solid #5fbae9;
		}
		
		input[type=text]:placeholder {
			color: #cccccc;
		}
		
		input[type=file] {
			border: none !important;
			padding: 0px !important;
		}
		
		input[type=button], input[type=submit], input[type=reset]  {
			width: 30% !important;
			background-color: #56baed;
			border: none !important;
			color: white !important;
			padding: 15px 80px;
			text-align: center;
			text-decoration: none;
			display: inline-block;
			text-transform: uppercase;
			font-size: 13px;
			-webkit-box-shadow: 0 10px 30px 0 rgba(95,186,233,0.4);
			box-shadow: 0 10px 30px 0 rgba(95,186,233,0.4);
			-webkit-border-radius: 5px 5px 5px 5px;
			border-radius: 5px 5px 5px 5px;
			-webkit-transition: all 0.3s ease-in-out;
			-moz-transition: all 0.3s ease-in-out;
			-ms-transition: all 0.3s ease-in-out;
			-o-transition: all 0.3s ease-in-out;
			transition: all 0.3s ease-in-out;
		}
		
		input[type=button]:hover, input[type=submit]:hover, input[type=reset]:hover  {
			background-color: #39ace7;
		}
		
		input[type=button]:active, input[type=submit]:active, input[type=reset]:active  {
			-moz-transform: scale(0.95);
			-webkit-transform: scale(0.95);
			-o-transform: scale(0.95);
			-ms-transform: scale(0.95);
			transform: scale(0.95);
		}	
		
		button {
			width: 30% !important;
			background-color: #56baed;
			border: none !important;
			color: white !important;
			padding: 0px !important;
			height: 43px !important;
			text-align: center;
			text-decoration: none;
			display: inline-block;
			text-transform: uppercase;
			font-size: 13px;
			 -webkit-box-shadow: 0 10px 30px 0 rgba(95,186,233,0.4);
			box-shadow: 0 10px 30px 0 rgba(95,186,233,0.4);
			-webkit-border-radius: 5px 5px 5px 5px;
			border-radius: 5px 5px 5px 5px;
			-webkit-transition: all 0.3s ease-in-out;
			-moz-transition: all 0.3s ease-in-out;
			-ms-transition: all 0.3s ease-in-out;
			-o-transition: all 0.3s ease-in-out;
			transition: all 0.3s ease-in-out;
		}

		button:hover {
			background-color: #39ace7;
			-webkit-box-shadow: 0 10px 30px 0 rgba(95,186,233,0.4);
			box-shadow: 0 10px 30px 0 rgba(95,186,233,0.4);
		}

		button:active{
			-moz-transform: scale(0.95);
			-webkit-transform: scale(0.95);
			-o-transform: scale(0.95);
			-ms-transform: scale(0.95);
			transform: scale(0.95);
		}
		
		button:disabled,
			button[disabled]{
				align-items: center !important;
				width: 30% !important;
				background-color: #cccccc;
				border: none;
				color: white;
				padding: 0px !important;
				height: 44px !important;
				text-decoration: none;
				display: inline-block;
				text-transform: uppercase;
				font-size: 13px;
				transform: scale(0.95);
				-webkit-box-shadow: 0 10px 30px 0 rgba(191,191,191,0.4);
				box-shadow: 0 10px 30px 0 rgba(191,191,191,0.4);
		}
		
		/*headings*/
		.fs-title {
			font-size: 15px;
			text-align: justify;
			color: #2C3E50;
			margin-bottom: 10px;
			font-size: 13px;
			line-height: normal;
		}
		
		.fs-subtitle {
			font-weight: normal;
			font-size: 13px;
			color: #666;
			margin-bottom: 20px;
		}
		
		/*progressbar*/
		#progressbar {
			margin-bottom: 30px;
			overflow: hidden;
			/*CSS counters to number the steps*/
			counter-reset: step;
		}
		
		#progressbar li {
			list-style-type: none;
			color: white;
			text-transform: uppercase;
			font-size: 9px;
			width: 33.33%;
			float: left;
			position: relative;
		}
		
		#progressbar li:before {
			content: counter(step);
			counter-increment: step;
			width: 20px;
			line-height: 20px;
			display: block;
			font-size: 10px;
			color: #333;
			background: white;
			border-radius: 3px;
			margin: 0 auto 5px auto;
		}
		
		/*progressbar connectors*/
		#progressbar li:after {
			content: '';
			width: 100%;
			height: 2px;
			background: white;
			position: absolute;
			left: -50%;
			top: 9px;
			z-index: -1; /*put it behind the numbers*/
		}
		
		#progressbar li:first-child:after {
			/*connector not needed before the first step*/
			content: none; 
		}
		
		/*marking active/completed steps green*/
		
		/*The number of the step and the connector before it = green*/
		#progressbar li.active:before,  #progressbar li.active:after{
			background: #39ace7;
			color: white;
		}
		h2 {
			text-align: left;
			font-size: 16px;
			font-weight: 600;
			text-transform: uppercase;
			display:inline-block;
			margin: 10px 8px 10px 8px; 
			color: #cccccc;
		}
		h2.inactive {
			color: #cccccc;
		}
		
		h2.active {
			color: #0d0d0d;
			border-bottom: 2px solid #5fbae9;
		}
		
		.checkboxes {
			display: flex;
			justify-content: center;
			align-items: top;
			vertical-align: center;
			word-wrap: break-word;
			margin-left: -13px;
			margin-top: 5px;
		}
		
		*:focus {
			outline: none;
			border-bottom: 2px solid #5fbae9  !important;
			-webkit-transition: all 0.5s ease-in-out;
			-moz-transition: all 0.5s ease-in-out;
			-ms-transition: all 0.5s ease-in-out;
			-o-transition: all 0.5s ease-in-out;
			transition: all 0.5s ease-in-out;
		} 
	
		h5{
			text-align:left;
			line-height: 40px;
			color: black;
			font-size: 13px;
		}
		
		table{
			text-align: left;
			font-size: 15px;
			width: 100%;
		}
		
		.radio{
			margin-left: 45px;
			width: 50%;
		}
		
		
		</style>
</head>
<body>
	<form id="msform" action="<?=base_url()?>/Registration_Controller/registerAccount" method="post" enctype="multipart/form-data">
	
		<!-- progressbar -->
		<ul id="progressbar">
			<li class="active">Personal Information</li>
			<li>Health Information</li>
			<li>Data Privacy Agreement</li>
		</ul>
		
		<!-- fieldsets -->
		<fieldset>
			<!-- Tabs Titles -->
			<h2 class="active"> Registration </h2><br>
			<h3 class="fs-subtitle">Personal Information</h3>
			
			<table>
				<tr> <td> <h5> First Name </h5> </td> <td> <input type="text" name="fname" value="<?= set_value("fname");?>" required/> </td> </tr>
				<font color="red"><?php echo form_error('fname', '<div class="error mb-3">', '</div>'); ?></font>
				
				<tr> <td> <h5> Middle Name </h5> </td><td> <input type="text" name="mname" value="<?= set_value("mname");?>" required/> </td> </tr>
				<font color="red"><?php echo form_error('mname', '<div class="error mb-3">', '</div>'); ?></font>
				
				<tr> <td> <h5> Last Name </h5> </td> <td> <input type="text" name="lname" value="<?= set_value("lname");?>" required/> </td> </tr>
				<font color="red"><?php echo form_error('lname', '<div class="error mb-3">', '</div>'); ?></font>
				
				<tr> <td> <h5> Gender </h5> </td> <td> 
					<input list="gender" name="gender">
					<datalist id="gender" name="gender" id="genderSelect" required>
						<option value="Male">Male</option>
						<option value="Female">Female</option>
					</datalist>
				</td> </tr>
				
				<tr> <td> <h5> Birthday </h5> </td> <td> <input type="date" name="birthdate" value="<?= set_value("birthdate");?>"/> </td> </tr>
				<?php echo form_error('birthdate', '<div class="error mb-3">', '</div>'); ?>

				<tr> <td> <h5> Username </h5> </td> <td> <input type="text" name="username" value="<?= set_value("username");?>" required/> </td> </tr>
				<font color="red"><?php echo form_error('username', '<div class="error mb-3">', '</div>'); ?></font>
				
				<tr> <td> <h5> Password </h5> </td> <td> <input type="password" name="password" required/> </td> </tr>
				<font color="red"><?php echo form_error('password', '<div class="error mb-3">', '</div>'); ?></font>
				
				<tr> <td> <h5> Confirm Password </h5> </td> <td> <input type="password" name="passconf"/> </td> </tr>
				<font color="red"><?php echo form_error('passconf', '<div class="error mb-3">', '</div>'); ?></font>
				
				<tr> <td> <h5> Email </h5> </td> <td> <input type="text" name="email" value="<?= set_value("email");?>" required/> </td> </tr>
				<font color="red"><?php echo form_error('email', '<div class="error mb-3">', '</div>'); ?></font>

				<tr> <td> <h5> Contact Number </h5> </td> <td> <input type="text"  name="contact" value="<?= set_value("contact");?>" required/> </td> </tr>
				<font color="red"><?php echo form_error('contact', '<div class="error mb-3">', '</div>'); ?></font>

				<tr> <td> <h5> House No.</h5> </td> <td> <input type="text" name="housenum" value="<?= set_value("housenum");?>"  required/> </td> </tr>
				<font color="red"><?php echo form_error('housenum', '<div class="error mb-3">', '</div>'); ?></font>

				<tr> <td> <h5> Street </h5> </td> <td> <input type="text"  name="street" value="<?= set_value("street");?>" required/> </td> </tr>
				<font color="red"><?php echo form_error('street', '<div class="error mb-3">', '</div>'); ?></font>

				<tr> <td> <h5> Subdivision </h5> </td> <td> <input type="text" name="subdivision" value="<?= set_value("subdivision");?>" required/> </td> </tr>
				<font color="red"><?php echo form_error('subdivision', '<div class="error mb-3">', '</div>'); ?></font>

				<tr> <td> <h5> Profile Picture</h5> </td> <td> <input type="file" id="profile_pic" name="profile_pic" value="<?= set_value("profile_pic");?>" required> </td> </tr>

				<tr> <td> <h5> Valid ID </h5> </td> <td> <input type="file" id="valid_id" name="validid" value="<?= set_value("validid");?>" required> </td> </tr>
				
				<tr> <td> <h5> Proof of Residency</h5> </td> <td> <input type="file" id="proof" name="proof" value="<?= set_value("proof");?>"> </td> </tr>
				
				<tr> <td> <h5> Priority Category </h5> </td> <td> 

				<select class="custom-select " name="priorityCateg" id="categSelect" style="width: 100%; border: 1px solid #ccc; border-radius: 3px; box-sizing: border-box; font-size: 13px; padding: 10px; font-family: 'Poppins', sans-serif; margin-bottom: 10px; border: 2px solid #ececec;">
						<?php foreach($category as $categ):?>
								<option value="<?=$categ->priority_id?>" selected>
									<?=$categ->priority_category?>
								</option>
						<?php endforeach;?>  
					</select>
				</td> </tr>
				
				<tr class="supporting-docs first-fourth"> <td> <h5> Cert. of Employement </h5> </td> <td> <input type="file" name="coe" value="<?= set_value("coe");?>"> </td> </tr>
				<tr class="supporting-docs second" > <td> <h5> Senior Citizen ID </h5> </td> <td> <input type="file"  name="senior" value="<?= set_value("senior");?>"> </td> </tr>
				<tr class="supporting-docs third" > <td> <h5> Medical Certificate </h5> </td> <td> <input type="file"   name="medcert" value="<?= set_value("medcert");?>"> </td> </tr>
				<tr class="supporting-docs third" > <td> <h5> Prescription </h5> </td> <td> <input type="file" id="valid_id"  name="prescrip" value="<?= set_value("prescrip");?>"> </td> </tr>
				<tr class="supporting-docs fifth"> <td> <h5> Certificate of Indigency </h5> </td> <td> <input type="file"  name="coi" value="<?= set_value("coi");?>"> </td> </tr>
				<tr class="supporting-docs others"> <td> <h5> Others </h5> </td> <td> <input type="file"  name="otherAttach" value="<?= set_value("otherAttach");?>"> </td> </tr>
			</table>
			
			<br><br>
			<input type="button" name="next" class="next action-button" value="Next" onclick="topFunction()"/>
			
		</fieldset>
		
		<fieldset>
			<h2 class="active"> Registration </h2><br>
			<h3 class="fs-subtitle">Health Information</h3>
			
			<div style="font-weight: bold; text-align: left;">TYPE OF COMORBIDITY:</div> <br>
			
			<table class="radio">
			
				<tr> 
					<td></td>
					<td> <h5> Allergies </h5> </td> 
					<td><nobr>
						<input type="radio" id="radioAllergy1" name="radioAllergy" value="Yes">
						<label for="radioAllergy1">Yes</label>
						<input type="radio" id="radioAllergy2" name="radioAllergy" value="No" checked>
						<label for="radioAllergy2">No</label>
					</nobr></td>	
				</tr>
				
				<tr> 
					<td></td>
					<td> <h5> Diseases </h5> </td> 
					<td><nobr>
						<input type="radio" id="radioDiseases1" name="radioDiseases" value="Yes">
						<label for="radioDiseases1">Yes</label>
						<input type="radio" id="radioDiseases2" name="radioDiseases" value="No" checked>
						<label for="radioDiseases2">No</label>
					</nobr></td>	
				</tr>
				
				<tr> 
					<td></td>
					<td> <h5> Diabetic </h5> </td> 
					<td><nobr>
						<input type="radio" id="radioDiabetic1" name="radioDiabetic" value="Yes">
						<label for="radioDiabetic1">Yes</label>
						<input type="radio" id="radioDiabetic2" name="radioDiabetic" value="No" checked>
						<label for="radioDiabetic2">No</label>
					</nobr></td>	
				</tr>
				
				<tr> 
					<td></td>
					<td> <h5> Hypertension </h5> </td> 
					<td><nobr>
						<input type="radio" id="radioHypertension1" name="radioHypertension" value="Yes">
						<label for="radioHypertension1">Yes</label>
						<input type="radio" id="radioHypertension2" name="radioHypertension" value="No" checked>
						<label for="radioHypertension2">No</label>
					</nobr></td>	
				</tr>
				
				<tr> 
					<td></td>
					<td> <h5> Organ Transplant </h5> </td> 
					<td><nobr>
						<input type="radio" id="radioOrgan1" name="radioOrgan" value="Yes">
						<label for="radioOrgan1">Yes</label>
						<input type="radio" id="radioOrgan2" name="radioOrgan" value="No" checked>
						<label for="radioOrgan2">No</label>
					</nobr></td>	
				</tr>
			
			</table>
	
			<br><br><div style="font-weight: bold; text-align: left;">COVID-19 SYMPTOMS:</div> <br>
			
			<table class="radio">
			
				<tr> 
					<td></td>
					<td> <h5> Fever </h5> </td> 
					<td><nobr>
						<input type="radio" id="radioFever1" name="radioFever" value="Yes">
						<label for="radioFever1">Yes</label>
						<input type="radio" id="radioFever2" name="radioFever" value="No" checked>
						<label for="radioFever2">No</label>
					</nobr></td>	
				</tr>
				
				<tr> 
					<td></td>
					<td> <h5> Cough </h5> </td> 
					<td><nobr>
						<input type="radio" id="radioCough1" name="radioCough" value="Yes">
						<label for="radioCough1">Yes</label>
						<input type="radio" id="radioCough2" name="radioCough" value="No" checked>
						<label for="radioCough2">No</label>
					</nobr></td>	
				</tr>
				
				<tr> 
					<td></td>
					<td> <h5> Body Pain </h5> </td> 
					<td><nobr>
						<input type="radio" id="radioBodyPain1" name="radioBodyPain" value="Yes">
						<label for="radioBodyPain1">Yes</label>
						<input type="radio" id="radioBodyPain2" name="radioBodyPain" value="No" checked>
						<label for="radioBodyPain2">No</label>
					</nobr>
					</td>
						
				</tr>
				
				<tr> 
					<td></td>
					<td> <h5> Shortness of Breath </h5> </td> 
					<td><nobr>
						<input type="radio" id="radioBreath1" name="radioBreath" value="Yes">
						<label for="radioBreath1">Yes</label>
						<input type="radio" id="radioBreath2" name="radioBreath" value="No" checked>
						<label for="radioBreath2">No</label>
					</nobr></td>	
				</tr>
				
				<tr> 
					<td></td>
					<td> <h5> Lost of Taste/Smell </h5> </td> 
					<td><nobr>
						<input type="radio" id="radioTaste1" name="radioTaste" value="Yes">
						<label for="radioTaste1">Yes</label>
						<input type="radio" id="radioTaste2" name="radioTaste" value="No" checked>
						<label for="radioTaste2">No</label>
					</nobr></td>	
				</tr>
				
				<tr> 
					<td></td>
					<td> <h5> Diarrhea </h5> </td> 
					<td><nobr>
						<input type="radio" id="radioDiarrhea1" name="radioDiarrhea" value="Yes">
						<label for="radioDiarrhea1">Yes</label>
						<input type="radio" id="radioDiarrhea2" name="radioDiarrhea" value="No" checked>
						<label for="radioDiarrhea2">No</label>
					</nobr></td>	
				</tr>
			
			</table>
			
			<br><br><div style="font-weight: bold; text-align: left;">OTHERS:</div> <br>
			<table>
			<tr> <td> <input type="text" name="others" placeholder="Please state here"/> </td> 
			<?php echo form_error('others', '<div class="error mb-3">', '</div>'); ?></tr>
			
			</table>
			
			<br><br>
			<input type="button" name="previous" class="previous action-button" value="Previous" onclick="topFunction()"/> &nbsp&nbsp&nbsp&nbsp&nbsp
			<input type="button" name="next" class="next action-button" value="Next" onclick="topFunction()"/>
	
		</fieldset>
		
		<fieldset>
			<h2 class="active"> Registration </h2><br>
			<h3 class="fs-subtitle">Data Privacy Agreement</h3>
			<h6 class="fs-title">
				&nbsp&nbsp&nbsp&nbsp&nbspThe iTUROK Co. recognizes their responsibilities under the Republic Act No. 10173 (Act), also known as the Data Privacy Act of 2012, with 
				respect to the data they collect, record, organize, update, use, consolidate or destruct from the vacinee. The personal data obtained from this portal is entered 
				and stored within the Institute’s authorized information and communications system and will only be accessed by the iTUROK Co. personnel. The iTUROK Co. have 
				instituted appropriate organizational, technical and physical security measures to ensure the protection of the alumni’s / donors’ personal data.
				<br><br>
				<div style="font-weight: bold">VACCINE CONSENT:</div>
				<br>
				&nbsp&nbsp&nbsp&nbsp&nbspI have read the Institute’s Data Privacy Statement and express my consent for the iTUROK Co. to collect, record, organize, update or modify, 
				retrieve, consult, use, consolidate, block, erase or destruct my personal data as part of my information.<br><br>
				<label for="consent" class="checkboxes">
				<input type="checkbox" id="consent"  name="checked" value="yes" class="checkboxes"  value="1" onclick="terms_changed(this)"/>
				I hereby affirm my right to be informed, object to processing, access and rectify, suspend or withdraw my personal data, and be indemnified in case of damages 
				pursuant to the provisions of the Republic Act No. 10173 of the Philippines, Data Privacy Act of 2012 and its corresponding Implementing Rules and Regulations.
				</label>
				<br>
				<div style="font-weight: bold; color: red;">NOTE: Please mark the check-box in order to submit the sign-up credentials.</div>
				<br>
			</h6>
			<input type="button" name="previous" class="previous action-button" value="Previous" onclick="topFunction()"/> &nbsp&nbsp&nbsp&nbsp&nbsp
			</div>
				<button type="submit" id="submit_button"   value="Submit" disabled />submit</button>	
				
				</div>
		</fieldset>
		
	</form>
	
	<br>
	
<!-- Javascript and Jquery, please don't remove -->
<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js'></script><script  src="./script.js"></script>
<script>

$(document).ready(function(){
	 	 $(".first-fourth").hide();
		  $(".second").hide();
		  $(".third").hide();
		  $(".fifth").hide();

		$('#categSelect').on('change', function(){
			
		    var value = $(this).val();
			$('div.suppDocs').hide();
		    if (value == '1'||value == '4') {
		        $(".first-fourth").show();
				$(".others").hide();
				$(".second").hide();
				$(".third").hide();
				$(".fifth").hide();
		    } 
		    else if (value == '2') {
		        $(".second").show();
				$(".others").hide();
				$(".first-fourth").hide();
				$(".third").hide();
				$(".fifth").hide();
		    }
			else if (value == '3') {
		        $(".third").show();
				$(".others").hide();
				$(".first-fourth").hide();
				$(".second").hide();
				$(".fifth").hide();
		    }
			else if (value == '5') {
		        $(".fifth").show();
				$(".others").hide();
				$(".first-fourth").hide();
				$(".second").hide();
				$(".third").hide();
		    }
			else if (value == '6') {
		        $(".others").show();
				$(".fifth").hide();
				$(".first-fourth").hide();
				$(".second").hide();
				$(".third").hide();
		    }
			else{
				$(".others").show();
				$(".fifth").hide();
				$(".first-fourth").hide();
				$(".second").hide();
				$(".third").hide();
			}
		});
		
	});

function topFunction() {
  document.body.scrollTop = 0; // For Safari
  document.documentElement.scrollTop = 0; // For Chrome, Firefox, IE and Opera
}

function terms_changed(termsCheckBox){
    //If the checkbox has been checked
    if(termsCheckBox.checked){
        //Set the disabled property to FALSE and enable the button.
        document.getElementById("submit_button").disabled = false;
		$("#id").toggleClass('disable');
    } else{
        //Otherwise, disable the submit button.
        document.getElementById("submit_button").disabled = true;
    }
}
//jQuery time
var current_fs, next_fs, previous_fs; //fieldsets
var left, opacity, scale; //fieldset properties which we will animate
var animating; //flag to prevent quick multi-click glitches

$(".next").click(function(){
	if(animating) return false;
	animating = true;
	
	current_fs = $(this).parent();
	next_fs = $(this).parent().next();
	
	//activate next step on progressbar using the index of next_fs
	$("#progressbar li").eq($("fieldset").index(next_fs)).addClass("active");
	
	//show the next fieldset
	next_fs.show(); 
	//hide the current fieldset with style
	current_fs.animate({opacity: 0}, {
		step: function(now, mx) {
			//as the opacity of current_fs reduces to 0 - stored in "now"
			//1. scale current_fs down to 80%
			scale = 1 - (1 - now) * 0.2;
			//2. bring next_fs from the right(50%)
			left = (now * 50)+"%";
			//3. increase opacity of next_fs to 1 as it moves in
			opacity = 1 - now;
			current_fs.css({
        'transform': 'scale('+scale+')',
        'position': 'absolute'
      });
			next_fs.css({'left': left, 'opacity': opacity});
		}, 
		duration: 800, 
		complete: function(){
			current_fs.hide();
			animating = false;
		}, 
		//this comes from the custom easing plugin
		easing: 'easeInOutBack'
	});
});

$(".previous").click(function(){
	if(animating) return false;
	animating = true;
	
	current_fs = $(this).parent();
	previous_fs = $(this).parent().prev();
	
	//de-activate current step on progressbar
	$("#progressbar li").eq($("fieldset").index(current_fs)).removeClass("active");
	
	//show the previous fieldset
	previous_fs.show(); 
	//hide the current fieldset with style
	current_fs.animate({opacity: 0}, {
		step: function(now, mx) {
			//as the opacity of current_fs reduces to 0 - stored in "now"
			//1. scale previous_fs from 80% to 100%
			scale = 0.8 + (1 - now) * 0.2;
			//2. take current_fs to the right(50%) - from 0%
			left = ((1-now) * 50)+"%";
			//3. increase opacity of previous_fs to 1 as it moves in
			opacity = 1 - now;
			current_fs.css({'left': left});
			previous_fs.css({'transform': 'scale('+scale+')', 'opacity': opacity});
		}, 
		duration: 800, 
		complete: function(){
			current_fs.hide();
			animating = false;
		}, 
		//this comes from the custom easing plugin
		easing: 'easeInOutBack'
	});
});

$(".submit").click(function(){
	return false;
})
</script>
</body>
</html>
