-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 22, 2021 at 05:47 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vaccination`
--

-- --------------------------------------------------------

--
-- Table structure for table `account_tbl`
--

CREATE TABLE `account_tbl` (
  `account_id` int(11) NOT NULL,
  `account_verificationNum` varchar(100) DEFAULT NULL,
  `account_fname` varchar(200) NOT NULL,
  `account_mname` varchar(200) NOT NULL,
  `account_lname` varchar(200) NOT NULL,
  `account_uname` varchar(200) NOT NULL,
  `account_password` varchar(200) NOT NULL,
  `account_approvalStat` int(11) NOT NULL,
  `account_status` int(11) NOT NULL,
  `account_bdate` date NOT NULL,
  `account_gender` varchar(100) NOT NULL,
  `account_housenum` varchar(200) NOT NULL,
  `account_street` varchar(200) NOT NULL,
  `account_subdivision` varchar(200) NOT NULL,
  `account_email` varchar(200) NOT NULL,
  `account_contactnum` varchar(200) NOT NULL,
  `account_prioritycateg` int(11) NOT NULL,
  `account_image` varchar(200) NOT NULL,
  `account_validid` varchar(200) NOT NULL,
  `account_residency` varchar(200) DEFAULT NULL,
  `account_registerdate` datetime NOT NULL,
  `account_ApprovedDate` datetime DEFAULT NULL,
  `account_allergy` varchar(100) NOT NULL,
  `account_disease` varchar(100) NOT NULL,
  `account_diabetic` varchar(100) NOT NULL,
  `account_hypertension` varchar(100) NOT NULL,
  `account_transplant` varchar(100) NOT NULL,
  `account_fever` varchar(100) NOT NULL,
  `account_cough` varchar(100) NOT NULL,
  `account_bodypain` varchar(100) NOT NULL,
  `account_breath` varchar(100) NOT NULL,
  `account_smell` varchar(100) NOT NULL,
  `account_diarrhea` varchar(100) NOT NULL,
  `account_others` varchar(100) DEFAULT NULL,
  `account_senior` varchar(200) DEFAULT NULL,
  `account_coe` varchar(200) DEFAULT NULL,
  `account_medcert` varchar(200) DEFAULT NULL,
  `account_medreceipt` varchar(200) DEFAULT NULL,
  `account_indigency` varchar(200) DEFAULT NULL,
  `account_otherAttach` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `account_tbl`
--

INSERT INTO `account_tbl` (`account_id`, `account_verificationNum`, `account_fname`, `account_mname`, `account_lname`, `account_uname`, `account_password`, `account_approvalStat`, `account_status`, `account_bdate`, `account_gender`, `account_housenum`, `account_street`, `account_subdivision`, `account_email`, `account_contactnum`, `account_prioritycateg`, `account_image`, `account_validid`, `account_residency`, `account_registerdate`, `account_ApprovedDate`, `account_allergy`, `account_disease`, `account_diabetic`, `account_hypertension`, `account_transplant`, `account_fever`, `account_cough`, `account_bodypain`, `account_breath`, `account_smell`, `account_diarrhea`, `account_others`, `account_senior`, `account_coe`, `account_medcert`, `account_medreceipt`, `account_indigency`, `account_otherAttach`) VALUES
(1, NULL, 'Liezyl', 'Sapitin', 'Tolentino', 'ltolentino', 'ltolentino09', 1, 1, '2000-02-09', 'Female', 'Blk. 39, Lot 8', 'Corymes Street', 'Harmony Hills 2', 'lie09tolentino@gmail.com', '09980476222', 1, 'avatar1.png', 'avatar1.png', 'proof.png', '2021-07-04 15:57:43', '2021-07-04 17:01:59', 'No', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes', 'No', 'No', 'No', 'No', 'No', NULL, 'R7123e3ecbbc960764e9f3748c85a24da.png', NULL, NULL, NULL, NULL),
(2, NULL, 'Cris', 'Sapitin', 'Tolentino', 'Cris23423423', 'newpwd123', 1, 1, '2021-07-09', 'Female', 'Blk 39 Lot 8', 'Germany', 'HH3', 'Cris122973@gmail.com', '09980476111', 2, 'avatar1.png', '0_vK_nZoaImoTd70iQ7.png', '1_6xsLSJvmA_AS15A4Cmk8Yg3.png', '2021-07-11 05:23:56', NULL, 'No', 'No', 'No', 'Yes', 'Yes', 'Yes', 'Yes', 'No', 'No', 'No', 'No', '', 'i21.png', '', '', '', '', ''),
(3, NULL, 'Juan', 'Dela', 'Cruz', 'Cruz34324234', 'Cruz34324234', 1, 1, '2021-07-02', 'Male', 'Blk 39 Lot 8', 'Kwedfgdf', 'dfgerter', 'lie@gmail.com', '09980476111', 6, 'avatar1.png', '1280px-SAS_logo_horiz_svg.png', '', '2021-07-11 08:08:20', NULL, 'No', 'No', 'No', 'No', 'No', 'Yes', 'No', 'No', 'No', 'No', 'Yes', '', '', '', '', '', '', '0_vK_nZoaImoTd70iQ8.png'),
(4, NULL, 'Diego', 'Aldon', 'Revera', 'Revera234324', 'new123456', 3, 1, '2021-07-03', 'Female', 'Blk 39 Lot 8', 'Villa', 'Rever', 'Revera234324@gmail.com', '09980476111', 4, 'avatar1.png', '0_vK_nZoaImoTd70iQ9.png', '', '2021-07-11 09:27:31', NULL, 'Yes', 'No', 'No', 'Yes', 'Yes', 'No', 'No', 'Yes', 'No', 'No', 'No', 'chronic', '', '1_6xsLSJvmA_AS15A4Cmk8Yg4.png', '', '', '', ''),
(5, NULL, 'Lorna', 'Mid', 'Cruz', 'lie09tolentino', 'lie09tolentinonew', 3, 1, '2020-12-16', 'Male', 'Block 9121 Lot 43534', 'Germany', 'HH8', 'dummy@gmail.com', '09122323223', 2, 'avatar1.png', '1280px-SAS_logo_horiz_svg1.png', 'barangay2.png', '2021-07-11 19:56:54', NULL, 'No', 'No', 'No', 'No', 'No', 'No', 'No', 'No', 'No', 'No', 'No', '', '0_vK_nZoaImoTd70iQ10.png', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `accstatus_tbl`
--

CREATE TABLE `accstatus_tbl` (
  `accstatus_id` int(11) NOT NULL,
  `accstatus_name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `accstatus_tbl`
--

INSERT INTO `accstatus_tbl` (`accstatus_id`, `accstatus_name`) VALUES
(1, 'Active'),
(2, 'Deactivated');

-- --------------------------------------------------------

--
-- Table structure for table `admin_tbl`
--

CREATE TABLE `admin_tbl` (
  `admin_id` int(11) NOT NULL,
  `admin_fname` varchar(200) NOT NULL,
  `admin_mname` varchar(200) NOT NULL,
  `admin_lname` varchar(200) NOT NULL,
  `admin_gender` varchar(100) DEFAULT NULL,
  `admin_bdate` date DEFAULT NULL,
  `admin_housenum` varchar(100) NOT NULL,
  `admin_street` varchar(100) DEFAULT NULL,
  `admin_subdivision` varchar(100) DEFAULT NULL,
  `admin_uname` varchar(200) NOT NULL,
  `admin_password` varchar(200) NOT NULL,
  `admin_email` varchar(200) NOT NULL,
  `admin_contactnum` varchar(200) NOT NULL,
  `admin_createdate` datetime NOT NULL,
  `admin_image` varchar(200) NOT NULL,
  `admin_accStatus` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin_tbl`
--

INSERT INTO `admin_tbl` (`admin_id`, `admin_fname`, `admin_mname`, `admin_lname`, `admin_gender`, `admin_bdate`, `admin_housenum`, `admin_street`, `admin_subdivision`, `admin_uname`, `admin_password`, `admin_email`, `admin_contactnum`, `admin_createdate`, `admin_image`, `admin_accStatus`) VALUES
(1, 'Daniel', 'Ad', 'Rebadavia', 'Female', '2021-07-13', 'Blk 12 Lot 3', 'Lilly', 'Blossom', 'admin12345', 'admin12345', 'admin1@gmail.com', '09982323241', '2021-07-04 16:28:57', 'avatar11.png', 1),
(4, 'Carlo', 'Dela', 'Paz', 'Male', '2021-07-09', 'Blk 89 Lot 6', 'Germany', 'Graceville', 'dumm12323', 'dumm12323', 'dumm12323@gmail.com', '09122323223', '2021-07-22 14:28:34', '', 1),
(5, 'Carlo', 'Dela', 'Paz', 'Male', '2021-07-09', 'Blk 89 Lot 6', 'Germany', 'Graceville', 'sampleAccount1212', 'sampleAccount1212', 'dumm12323@gmail.com', '09122323223', '2021-07-22 14:30:25', 'avatar111.png', 1);

-- --------------------------------------------------------

--
-- Table structure for table `approvalstat_tbl`
--

CREATE TABLE `approvalstat_tbl` (
  `approvalstat_id` int(11) NOT NULL,
  `approvalstat_name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `approvalstat_tbl`
--

INSERT INTO `approvalstat_tbl` (`approvalstat_id`, `approvalstat_name`) VALUES
(1, 'Approved'),
(2, 'Denied'),
(3, 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `barangayinfo_tbl`
--

CREATE TABLE `barangayinfo_tbl` (
  `barangayinfo_id` int(11) NOT NULL,
  `barangayinfo_name` varchar(200) NOT NULL,
  `barangayinfo_vaccsite` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `barangayinfo_tbl`
--

INSERT INTO `barangayinfo_tbl` (`barangayinfo_id`, `barangayinfo_name`, `barangayinfo_vaccsite`) VALUES
(1, 'San Antonio', 'Barangay Hall');

-- --------------------------------------------------------

--
-- Table structure for table `priority_tbl`
--

CREATE TABLE `priority_tbl` (
  `priority_id` int(11) NOT NULL,
  `priority_category` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `priority_tbl`
--

INSERT INTO `priority_tbl` (`priority_id`, `priority_category`) VALUES
(1, 'A1 - Medical Frontliners'),
(2, 'A2 - Senior Citizens'),
(3, 'A3 - Person with Comorbidity'),
(4, 'A4 - Economic Frontliners'),
(5, 'A5 - Indigent Citizen'),
(6, 'Others');

-- --------------------------------------------------------

--
-- Table structure for table `vaccinationstas_tbl`
--

CREATE TABLE `vaccinationstas_tbl` (
  `vaccinationStas_id` int(11) NOT NULL,
  `vaccinationStas_name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vaccinationstas_tbl`
--

INSERT INTO `vaccinationstas_tbl` (`vaccinationStas_id`, `vaccinationStas_name`) VALUES
(1, 'Administered'),
(2, 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `vaccination_tbl`
--

CREATE TABLE `vaccination_tbl` (
  `vaccination_id` int(11) NOT NULL,
  `vaccination_resid` int(11) NOT NULL,
  `vaccination_firstsched` date NOT NULL,
  `vaccination_firstStatus` int(11) NOT NULL,
  `vaccination_fLotNumber` varchar(100) DEFAULT NULL,
  `vaccination_fAdminDate` date NOT NULL,
  `vaccination_fAdminId` int(11) NOT NULL,
  `vaccination_secsched` date NOT NULL,
  `vaccination_secStatus` int(11) NOT NULL,
  `vaccination_sLotNumber` varchar(100) NOT NULL,
  `vaccination_sAdminDate` date NOT NULL,
  `vaccination_sAdminId` int(11) NOT NULL,
  `vaccination_brand` varchar(200) NOT NULL,
  `vaccination_site` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vaccination_tbl`
--

INSERT INTO `vaccination_tbl` (`vaccination_id`, `vaccination_resid`, `vaccination_firstsched`, `vaccination_firstStatus`, `vaccination_fLotNumber`, `vaccination_fAdminDate`, `vaccination_fAdminId`, `vaccination_secsched`, `vaccination_secStatus`, `vaccination_sLotNumber`, `vaccination_sAdminDate`, `vaccination_sAdminId`, `vaccination_brand`, `vaccination_site`) VALUES
(1, 1, '0000-00-00', 0, NULL, '0000-00-00', 0, '0000-00-00', 0, '', '0000-00-00', 0, '', ''),
(2, 3, '0000-00-00', 0, NULL, '0000-00-00', 0, '0000-00-00', 0, '', '0000-00-00', 0, '', ''),
(3, 2, '0000-00-00', 0, NULL, '0000-00-00', 0, '0000-00-00', 0, '', '0000-00-00', 0, '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account_tbl`
--
ALTER TABLE `account_tbl`
  ADD PRIMARY KEY (`account_id`);

--
-- Indexes for table `accstatus_tbl`
--
ALTER TABLE `accstatus_tbl`
  ADD PRIMARY KEY (`accstatus_id`);

--
-- Indexes for table `admin_tbl`
--
ALTER TABLE `admin_tbl`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `approvalstat_tbl`
--
ALTER TABLE `approvalstat_tbl`
  ADD PRIMARY KEY (`approvalstat_id`);

--
-- Indexes for table `barangayinfo_tbl`
--
ALTER TABLE `barangayinfo_tbl`
  ADD PRIMARY KEY (`barangayinfo_id`);

--
-- Indexes for table `priority_tbl`
--
ALTER TABLE `priority_tbl`
  ADD PRIMARY KEY (`priority_id`);

--
-- Indexes for table `vaccinationstas_tbl`
--
ALTER TABLE `vaccinationstas_tbl`
  ADD PRIMARY KEY (`vaccinationStas_id`);

--
-- Indexes for table `vaccination_tbl`
--
ALTER TABLE `vaccination_tbl`
  ADD PRIMARY KEY (`vaccination_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account_tbl`
--
ALTER TABLE `account_tbl`
  MODIFY `account_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `accstatus_tbl`
--
ALTER TABLE `accstatus_tbl`
  MODIFY `accstatus_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `admin_tbl`
--
ALTER TABLE `admin_tbl`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `approvalstat_tbl`
--
ALTER TABLE `approvalstat_tbl`
  MODIFY `approvalstat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `barangayinfo_tbl`
--
ALTER TABLE `barangayinfo_tbl`
  MODIFY `barangayinfo_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `priority_tbl`
--
ALTER TABLE `priority_tbl`
  MODIFY `priority_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `vaccinationstas_tbl`
--
ALTER TABLE `vaccinationstas_tbl`
  MODIFY `vaccinationStas_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `vaccination_tbl`
--
ALTER TABLE `vaccination_tbl`
  MODIFY `vaccination_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
